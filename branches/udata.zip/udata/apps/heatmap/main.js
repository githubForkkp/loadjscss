/**
 * 热图模块
 * @author gonghao.gh
 * @date 2013-08-12
 */
(function($){
    $.namespace('UData.apps.heatmap');
    var common = UData.common,
        menu = UData.menu,
        spmPosition = UData.apps.spmPosition,
        pageBody = $(document.body);

    UData.apps.heatmap = {

        getImg: function(date) {
            var url = "http://ushu.taobao.net/getf/",
                xwj_id = this.xwj_id,
                timestamp = date.split("-").join("").substring(2),
                src = [url, "hm_heat_all_v_", xwj_id.split("-")[1], "_", timestamp, ".png"].join("");

            if (!this.imgBuilt) {
                this.buildImgContainer(src);
            } else {
                this.imgContainer.attr("src", src);
            }
        },

        buildImgContainer: function(src) {
            this.imgContainer = $("<img>").attr("src", src).addClass("udata-heatmap").appendTo(pageBody);
            this.imgContainer.error(function() {
                alert("热图不存在或已过期。");
            });

            this.imgBuilt = true;
        },

        initDatepicker: function(date) {
            var that = this;

            if (!date) {
                return;
            }

            that.calendar.val(date);
            common.manageNextDay(that.nextDayBtn, date, that.maxDate);
            if(!that.hasBuildDatePicker){
                that.calendar.datepicker({
                    defaultDate: date,
                    maxDate: that.maxDate,
                    dateFormat:'yy-mm-dd',
                    onSelect: function(dateText, inst){
                        if(that.calendar.val() === dateText){
                            return;
                        }
                        that.getData(dateText);
                        common.setFakeDay(dateText);
                        menu.showPageData(dateText);
                    }
                });
                that.hasBuildDatePicker = true;
                common.setFakeDay(date);
                menu.showPageData(date);
                this.calendar.siblings("ins.udata-date-overlay").show();
            }
        },

        gotoPreviousDay: function() {
            var that = this,
                currentDate,
                yesterday;

            if (this.invalid) {
                return;
            }

            currentDate = that.calendar.datepicker("getDate");
            that.calendar.datepicker("hide");
            yesterday = currentDate.addDays(-1).toString('yyyy-MM-dd');
            that.getImg(yesterday);
            common.setFakeDay(yesterday);
            menu.showPageData(yesterday);
        },

        gotoNextDay: function() {
            var that = this,
                currentDate,
                tomorrow;

            if (this.invalid) {
                return;
            }

            currentDate = that.calendar.datepicker("getDate");
            that.calendar.datepicker("hide");
            tomorrow = currentDate.addDays(1).toString('yyyy-MM-dd');
            that.getImg(tomorrow);
            common.setFakeDay(tomorrow);
            menu.showPageData(tomorrow);
        },

        run: function(calendar, nextDayBtn) {
            var that = this,
                xwj_id = common.getXwjId(),
                date = spmPosition.getSyncDate();

            that.calendar = calendar;
            that.nextDayBtn = nextDayBtn;

            this.maxDate = common.getDate(null, -1);
            that.initDatepicker(date);
            if(xwj_id) {
                this.xwj_id = xwj_id;
                this.getImg(date);
            } else {
                alert("该页面暂无热图。");
                this.stop();
                $(".udata-date-overlay").text("");
                this.invalid = true;
            }
        },

        stop: function() {
            if (this.imgContainer) {
                this.imgContainer.hide();
            }
            spmPosition.setSyncDate(this.calendar.val());
            this.hasBuildDatePicker = false;
            this.calendar.datepicker("hide");
            this.calendar.datepicker('destroy');
            this.calendar.val('');
            this.calendar.siblings("ins.udata-date-overlay").hide();
            this.invalid = false;
        }
    };
})(jQuery);