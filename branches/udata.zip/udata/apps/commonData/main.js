/**
 * author: oldj
 * blog: http://oldj.net
 */

(function ($) {
	$.namespace('UData.apps.commonData');

	var common = UData.common;

	UData.apps.commonData = {
		intervalDo: function () {
			if ($("body").attr("data-udata-app-public-close")) {
				this.stop();
				UData.menuBar.find("dt[data-function$=commonData]").click();
				return null;
			}
			return $("input[type=hidden]").each(function () {
				var url,
					_this = this;
				if ($(this).hasClass("udata-url-request")) {
					url = $(this).attr("data-url");
					return $.get(url, function (r) {
						return $(_this).val(r).addClass("done");
					});
				}
				return null;
			});
		},
		ifrInit: function () {
			if (this.ifr.is_initialized) {
				return null;
			}
			this.ifr.is_initialized = true;
			$(this.ifr).css({
				position: "absolute",
				zIndex: 2147483647,
				top: 0,
				left: 0,
				width: "100%",
				height: "100%",
				scroll: "auto",
				border: "none",
				display: "none"
			});
			$("body").append(this.ifr);
			this.ifr.contentDocument.open();
			this.ifr.contentDocument.write(this.getIframeContentHTML());
			return this.ifr.contentDocument.close();
		},
		getIframeContentHTML: function () {
			return common.getLocalFile("apps/commonData/c.html", {
				appid: common.getAppIdInPage()
			});
		},
		run: function () {
			var _this = this;
			this.is_running = true;
			this.origin_scroll_top = document.body.scrollTop;
			document.body.scrollTop = 0;
			if (!this.ifr) {
				this.ifr = document.createElement("iframe");
			}
			this.ifrInit();
			$("html, body").addClass("UDATA-body");
			$(this.ifr).slideDown("slow");
			return this._t_interval = setInterval((function () {
				return _this.intervalDo();
			}), 200);
		},
		stop: function () {
			var _this = this;
			this.is_running = false;
			console.log("public end...");
			$("body").removeAttr("data-udata-app-public-close");
			clearInterval(this._t_interval);
			return $(this.ifr).slideUp(function () {
				document.body.scrollTop = _this.origin_scroll_top;
				return setTimeout((function () {
					if (!_this.is_running) {
						return $("html, body").removeClass("UDATA-body");
					}
					return null;
				}), 200);
			});
		}
	};
})(jQuery);
