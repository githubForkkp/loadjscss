/**
 * SPM模块数据（包含历史数据，依赖于spmHistory中的显示窗口）
 * @author gonghao.gh
 * @date 2013-07-31
 */
(function($) {
    $.namespace("UData.apps.spmModule");

    var common = UData.common,
        menu = UData.menu,
        spmHistory = UData.apps.spmHistory,
        spmPosition = UData.apps.spmPosition,
        pageBody = $(document.body),
        url = "http://shuju.taobao.ali.com/rms/pub/spmModuleDateData.htm",
        hisUrl = "http://shuju.taobao.ali.com/rms/pub/spmModuleHistoryData.htm",
        chunkTimer;

    var chunk = function(array, process, context, callback) {
        setTimeout(function() {
            var item = array.shift();
            process.call(context, item);
            if (array.length>0) {
                chunkTimer = setTimeout(arguments.callee, 1);
            } else if (array.length===0 && $.isFunction(callback)) {
                callback.call(context);
            }
        },1);
    };

    UData.apps.spmModule = {

        initialized: false,

        bindEvent: function() {

            var that = this,
                timer;

            that.overlay.delegate(".udata-module-container", "mouseenter", function(e) {
                var $target = $(e.target),
                    $container = $target.closest(".udata-module-container");

                $container.find(".udata-module-block").addClass("udata-module-highlight");
                $container.find(".udata-module-tag").addClass("udata-module-higherlayer");
                return false;
            });

            that.overlay.delegate(".udata-module-container", "mouseleave", function(e) {
                var $target = $(e.target),
                    $container = $target.closest(".udata-module-container");

                $container.find(".udata-module-block").removeClass("udata-module-highlight");
                $container.find(".udata-module-tag").removeClass("udata-module-higherlayer");
                return false;
            });

            that.overlay.delegate(".udata-module-history", "click", function(e) {
                var $target = $(e.target),
                    a_container = $target.closest(".udata-module-container")[0],
                    pos = spmHistory.findSuitablePos(e.pageX+6, e.pageY+6, $target[0]),
                    spmId = common.getSPMId()+"."+a_container.getAttribute("data-spm-info"),
                    curDate = $(".udata-calendar").datepicker("getDate"),
                    startDate = common.getDate(curDate, -6),
                    endDate = common.getDate(curDate);

                spmHistory.fail.hide();
                spmHistory.container.hide();
                // 参数传递
                var data = {
                    //callback: "func",
                    spmId: spmId,
                    startDate: startDate,
                    endDate: endDate,
                    _: new Date().getTime()
                };

                spmHistory.dialogModule.css({"left":pos.left, "top":pos.top}).show();
                spmHistory.loading.show();
                spmHistory.container.hide();
                $(".udata-history-title").text("模块详情");
                spmHistory.dialogModule.find(".udata-history-nav").children().eq(2).hide();
                $.ajax({
                    url: hisUrl,
                    data: data,
                    dataType: "json",
                    success: function(json) {
                        //console.log(json);
                        spmHistory.showChart(json);
                    },
                    error: function() {
                        console.log("error");
                    }
                });

                $(document).one('click', function() {
                    spmHistory.dialogModule.fadeOut();
                });
                return false;
            });
        },

        buildOverlay: function() {
            this.overlay = $('<div class="udata-module-overlay"></div>');
            this.overlay.appendTo(pageBody);
        },

        getData: function(date) {
            var that = this,
                data = {
                    spmId : this.spmPageId
                };
            that.currentDate = date;

            if (common.loadingBox){
                common.loadingBox.show();
            } else {
                common.buildLoading();
            }

            if (!this.overlay) {
                this.buildOverlay();
            }
            if (!this.initialized) {
                this.bindEvent();
            }

            if(date){
                data['date'] = date;
            }
            $.ajax({
                url : url,
                data : data,
                dataType : 'json'
            }).done(function(o){
                var data,
                    date;
                if(!o){
                    return;
                }
                if(o.success){
                    data = o.data;
                    date = o.date;
                    that.maxDate = that.maxDate || o.maxDate;
                    //停掉上一个日期数据进程
                    clearTimeout(that.dynamicTimer);
                    clearTimeout(chunkTimer);
                    that.initDatepicker(date);
                    that.dataMap = data;
                    that.show();
                    console.log(date, data);
                }
                else{
                    if(o.message === '没有获取到对应数据'){
                        that.getData((date?Date.parse(date).addDays(-1):Date.today().addDays(-2)).toString('yyyy-MM-dd'), type);
                    } else {
                        alert(o.message);
                    }
                }
                common.loadingBox.hide();
            });
        },

        initDatepicker: function(date) {
            var that = this;
            that.calendar.val(date);
            common.manageNextDay(that.nextDayBtn, date, that.maxDate);
            if(!that.hasBuildDatePicker){
                that.calendar.datepicker({
                    defaultDate: date,
                    maxDate: that.maxDate,
                    dateFormat:'yy-mm-dd',
                    onSelect: function(dateText, inst){
                        if(that.currentDate === dateText){
                            return;
                        }
                        that.getData(dateText);
                        common.setFakeDay(dateText);
                        menu.showPageData(dateText);
                    }
                });
                that.hasBuildDatePicker = true;
                common.setFakeDay(date);
                menu.showPageData(date);
                that.calendar.siblings("ins.udata-date-overlay").show();
            }
        },

        gotoPreviousDay: function() {
            var that = this,
                currentDate,
                yesterday;

            currentDate = that.calendar.datepicker("getDate");
            that.calendar.datepicker("hide");
            yesterday = currentDate.addDays(-1).toString('yyyy-MM-dd');
            that.getData(yesterday);
            common.setFakeDay(yesterday);
            menu.showPageData(yesterday);
        },

        gotoNextDay: function() {
            var that = this,
                currentDate,
                tomorrow;

            currentDate = that.calendar.datepicker("getDate");
            that.calendar.datepicker("hide");
            tomorrow = currentDate.addDays(1).toString('yyyy-MM-dd');
            that.getData(tomorrow);
            common.setFakeDay(tomorrow);
            menu.showPageData(tomorrow);
        },

        show: function(modules) {
            this.modules = modules || $.makeArray($("*[data-spm]"));
            chunk(this.modules, this.showModuleData, this, this.showDynamic);
        },

        showModuleData: function(item) {
            var $item = $(item),
                spmc = $item.data("spm"),
                data,
                des = $('div[data-spm-info="'+spmc+'"]');

            if (des.length > 0) {
                var ps = des.first().find("p");
                if (data = this.dataMap[spmc]) {
                    ps.eq(0).html("PV:"+data.pv);
                    ps.eq(1).html("UV:"+data.uv);
                }
            }else if ((data = this.dataMap[spmc]) && this.checkValidTag(item)) {
                this.buildModule($item, spmc, data);
            }
        },

        checkValidTag: function(item) {
            var excludedTagName = {
                "BODY": true,
                "A": true,
                "AREA": true,
                "BUTTON": true,
                "INPUT": true
            };

            return !excludedTagName[item.tagName];
        },

        buildModule: function($item, spmc, data) {
            var offset = $item.offset(),
                minLeft = Math.max(offset.left, 50),
                top = offset.top+"px",
                left = minLeft+"px",
                width = $item[0].offsetWidth+"px",
                height = $item[0].offsetHeight+"px";

            var module = $('<div class="udata-module-block"></div>');
            module.css({top: top, left: left, width: width, height: height});

            var tag = $('<div class="udata-module-tag"><p>PV:'+data.pv+'</p><p>UV:'+data.uv+'</p><p class="udata-module-history" style="background:url('+chrome.extension.getURL("")+'apps/spmHistory/history.png) no-repeat">查看更多</p></div>');
            tag.css({top: top, left: left});

            var container = $('<div class="udata-module-container"></div>');
            container.attr("data-spm-info", spmc).append(module).append(tag);
            // 加上标记
            $item.attr("data-module-checked", true);

            container.appendTo(this.overlay);
        },

        showDynamic: function() {
            var that = this,
                modules = $.makeArray($("*[data-spm]").filter(":not([data-module-checked])")),
                res = [];

            this.dynamicTimer = setTimeout(function(){
                modules.map(function(item) {
                    if (that.checkValidTag(item)) {
                        res.push(item);
                    }
                });
                that.show(res);
            }, 3000);
        },

        run: function(calendar, nextDayBtn) {
            var that = this, date;
            that.calendar = calendar;
            that.nextDayBtn = nextDayBtn;

            that.spmPageId = that.spmPageId || common.getSPMId();
            if(!that.spmPageId || that.spmPageId==='0.0' || that.spmPageId==='0.0.0'){
                return;
            }

            pageBody.removeClass("udata-module-stop");
            if (date = spmPosition.getSyncDate()) {
                that.getData(date)
            } else {
                that.getData();
            }
        },

        stop: function() {
            spmHistory.dialogModule.hide();
            spmPosition.setSyncDate(this.currentDate);
            pageBody.addClass("udata-module-stop");
            this.hasBuildDatePicker = false;
            spmHistory.dialogModule.find(".udata-history-nav").children().eq(2).show();
            this.calendar.datepicker("hide");
            this.calendar.datepicker('destroy');
            this.calendar.siblings("ins.udata-date-overlay").hide();
            this.calendar.val('');
        }
    };

})(jQuery);