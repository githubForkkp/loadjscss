/**
 * 页面点击快照模块
 * @author : yu.yuy
 * @createTime : 2013-06-02
 */
 (function($){
 	$.namespace('UData.apps.click');

 	var common = UData.common,
 	html = $('html'),
 	doc = $(document),
 	body = $(document.body),
	iframe,
	currentUrl = location.protocol+'//'+location.host+location.pathname,
	dataUrl = 'http://shuju.taobao.ali.com/atpanel2/clickView.do',
	isOpened = false,
	searchBtn,
	closeBtn,
	dateTime,
	pageId = null,
	hasBuildDatePicker = false,
	clickDistributionContainer,
	defaultParams = {
		pageType : 1,
		dataHour : 14,
		clickType : 'pv',
		showType : 'number'
	};
 	UData.apps.click = {
		createIframe : function(container,fn){
			var that = this;
			iframe = document.createElement('iframe');
			iframe.frameSpacing = 0;
			iframe.frameBorder = 0;
			//iframe.width = doc.width();
			iframe.onload = fn || $.noop();
			that.getNewData(that.getYesterdayDate());
			container.append(iframe).show();
		},
		getYesterdayDate : function(){
			var now = new Date(),
			year = now.getFullYear(),
			month = now.getMonth()+1,
			day = now.getDate()-1,
			ret = [];
			ret.push(year);
			ret.push(month<10?'0'+month:month);
			ret.push(day<10?'0'+day:day);
			return ret.join('-');
		},
		getNewData : function(date){
			var that = this,
			url = 'http://shuju.taobao.ali.com/atpanel2/pub/service/pageClickData.htm';
			$.ajax({
				url : url,
				dataType : 'html',
				scriptCharset: 'utf-8',
				data : {
					url : currentUrl,
					date : date,
					flush : true
				},
				success : function(s){
					var str = s.replace(/&quot;/g,'"'),
					o = $.parseJSON(str);
					if(o && o.isSuccess){
						var data = o.data,
						minDate = data['startDate'];
						that.maxDate = data['endDate'];
						pageId = data['pageId'];
						
						if(!hasBuildDatePicker){
							that.calendar.datepicker({
								defaultDate:date,
								maxDate : that.maxDate,
								dateFormat:'yy-mm-dd',
								onSelect : function(dateText, inst){
									that.update(dateText);
								}
							});
							hasBuildDatePicker = true;
						}
						that.calendar.val(that.maxDate);
						that.update(that.maxDate);
					}
					else{
						console.info(o);
					}
				}
			});
		},
		gotoPreviousDay : function(el){
			var that = this,
			currentDate,
			yesterday;
			currentDate = that.calendar.datepicker( "getDate");
			that.calendar.datepicker( "hide");
 			yesterday = currentDate.addDays(-1).toString('yyyy-MM-dd');
 			that.calendar.val(yesterday);
 			that.update(yesterday);
		},
		gotoNextDay : function(){
			var that = this,
			currentDate,
			tomorrow,
			maxDate = that.calendar.datepicker( "option", "maxDate" );
			currentDate = that.calendar.datepicker( "getDate");
			that.calendar.datepicker( "hide");
 			tomorrow = currentDate.addDays(1).toString('yyyy-MM-dd');
 			that.calendar.val(tomorrow);
 			that.update(tomorrow);
		},
		createUrl : function(pageId,date){
			var params = [];
			defaultParams['pageId'] = pageId;
			defaultParams['dataDate'] = date;
			for(var i in defaultParams){
				if(defaultParams.hasOwnProperty(i)){
					params.push(i+'='+defaultParams[i]);
				}
			}
			return dataUrl+'?'+params.join('&');
		},
		update : function(date){
			var that = this;
			common.manageNextDay(that.nextDayBtn,date,that.maxDate);
			iframe.src = that.createUrl(pageId,date);
		},
		stop : function(){
			var that = this;
			that.clickDistributionContainer.html('');
			html.removeClass('udata-click-pattern');
			that.clickDistributionContainer.hide();
			that.calendar.datepicker('hide');
			that.calendar.datepicker('destroy');
			that.calendar.val('');
            that.calendar.siblings("ins.udata-date-overlay").hide();
			hasBuildDatePicker = false;
		},
		run : function(calendar,nextDayBtn,type){
			var that = this;
			that.calendar = calendar;
			that.nextDayBtn = nextDayBtn;
			that.createIframe(that.clickDistributionContainer);
			html.addClass('udata-click-pattern');
		},
		init : function(){
			var that = this;
			that.clickDistributionContainer = $('<div class="udata-click-distribution"></div>');
			body.append(that.clickDistributionContainer);
		}
	};
	UData.apps.click.init();
 })(jQuery);