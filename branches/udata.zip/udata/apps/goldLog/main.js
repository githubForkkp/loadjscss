/**
 * @Description: 黄金令箭埋点
 * @Author:      dafeng.xdf[at]taobao.com
 * @Date:        2013.6.21
 */
(function($){
    $.namespace('UData.apps.goldLog');
    var html = $('html'),
        doc = $(document),
        body = $(document.body),
        self = this,
        DATA = 'spm-click',
        common = UData.common,
        goldApi = 'http://shuju.taobao.ali.com/rms/pub/SpmResourceLogkeyData.htm',
        CONTAINER_CLS = 'udata-gold-tip-container',
        getDate = false,
        __date;
    var _goldLog = {
        init : function(){
            var self = this;
            self.type  = 'pv';
        },
        validate:function(){
            new goldLogValidate();
        },
        getDate:function(){
            var self = this;
            return Date.today().addDays(-1).toString('yyyy-MM-dd');
        },
        createTpl:function(s){
            var self = this,
                pvHide = '',
                uvHide = '',
                type = self.type;
            switch(type){
                case 'pv':
                    uvHide = 'hide';
                    break;
                case 'uv':
                    pvHide = 'hide';
                    break;
                default:
                    uvHide = 'hide';
                    break;
            }
            return ['<inc class="udata-gold-pv '+pvHide+'">'+ s.pv+'</inc>' +
                '<inc class="udata-gold-uv '+uvHide+'">'+ s.uv+'</inc>'].join('');
        },
        buildTips:function(data){
            var self = this;
            $('[data-spm-click]').each(function(i,e){
                var _target = $(e),
                    _data = data[$(e).data('spm-anchor-id')];
                if(_data){
                    _target.addClass(CONTAINER_CLS);
                    _target.append(self.createTpl(_data));
                }
            });
        },
        /*
        getData:function(day){
            var self = this;
            $.ajax({
                url : goldApi,
                dataType : 'html',
                scriptCharset: 'utf-8',
                data : {
                    date : day || self.getDate(),
                    spm_id: common.getSPMId()
                },
                success : function(s){
                    var o = $.parseJSON(s);
                    if(o.success){
                        var data = o.data,
                            date = o.date;
                        self.initDatepicker(date);
                        self.buildTips(data);
                    }else{
                        console.log(o.message);
                    }
                }
            });
        },
        gotoPreviousDay : function(){
            var that = this,
                currentDate,
                yesterday;
            currentDate = that.calendar.datepicker( "getDate");
            that.calendar.datepicker( "hide");
            yesterday = currentDate.addDays(-1).toString('yyyy-MM-dd');
            that.getData(yesterday);
        },
        gotoNextDay : function(){
            var that = this,
                currentDate,
                tomorrow;
            currentDate = that.calendar.datepicker( "getDate");
            that.calendar.datepicker( "hide");
            tomorrow = currentDate.addDays(1).toString('yyyy-MM-dd');
            that.getData(tomorrow);
        },
        initDatepicker : function(date){
            var that = this;
            that.calendar.val(date);
            that.removeTips();
            __date = date;
            common.manageNextDay(that.nextDayBtn,date,that.maxDate);
            if(!that.hasBuildDatePicker){
                that.calendar.datepicker({
                    defaultDate:date,
                    maxDate : that.maxDate,
                    dateFormat:'yy-mm-dd',
                    onSelect : function(dateText, inst){
                        if(that.currentDate === dateText){
                            return;
                        }

                        that.getData(dateText);

                    }
                });
                that.hasBuildDatePicker = true;
            }
        }, */
        getPv:function(data){
            var self = this;
            self.buildTips(data);
            $('.udata-gold-pv').removeClass('hide');
            $('.udata-gold-uv').addClass('hide');
        },
        getUv:function(data){
            var self = this;
            self.buildTips(data);
            $('.udata-gold-pv').addClass('hide');
            $('.udata-gold-uv').removeClass('hide');
        },
        stop:function(){
            $('.udata-gold-tip,.udata-gold-icon,.udata-gold-uv,.udata-gold-pv').remove();
            self.currentGoldLog = null;
            getDate = false;
        },
        removeTips:function(){
            $('.udata-gold-uv,.udata-gold-pv').remove();
        },
        removeValTips:function(){
            //$('.udata-gold-tip,.udata-gold-icon').remove();
            $('.udata-gold-tip,.udata-gold-icon,.udata-gold-uv,.udata-gold-pv').remove();
            self.currentGoldLog = null;
        },
        run : function(calendar, nextDay, type, data){
            var self = this;
            if (arguments.length == 3) {
                self.type = arguments[2];
            } else {
                self.type = type;
            }
            switch(self.type) {
                case 'validate':
                    self.removeTips();
                    self.validate();
                    break;
                case 'uv':
                    self.removeValTips();
                    self.type = 'uv';
                    self.getUv(data);
                    break;
                case 'pv':
                    self.removeValTips();
                    self.type = 'pv';
                    self.getPv(data);
                    break;
            }
        }
    };
    UData.apps.goldLog = _goldLog;
    _goldLog.init();
})(jQuery);
