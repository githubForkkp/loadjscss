/**
 * @Description: 黄金令箭埋点校验
 * @Author:      dafeng.xdf[at]taobao.com
 * @Date:        2013.6.21
 */
(function ($) {
    var common = UData.common,
        DATA = 'spm-click',
        CONTAINER_CLS = 'udata-gold-tip-container',
        ICON_CLS = 'udata-gold-icon ',
        TIP_CLS = 'udata-gold-tip',
        STATUS = {
            0:{status:'ok',tips:'校验合格！'},
            1:{status:'remove',tips:'令箭格式有误'},
            10:{status:'remove',tips:'令箭业务段gostr信息错误'},
            11:{status:'ban',tips:'令箭业务段gostr信息格式不正确'},
            20:{status:'remove',tips:'令箭位置locaid信息错误'},
            21:{status:'ban',tips:'令箭位置locaid信息格式不正确'}
        },
        validateApi = 'http://shuju.taobao.ali.com/rms/pub/SpmIsExitBusType.htm';
    function goldLogValidate() {
        this.init();
    }
    goldLogValidate.prototype = {
        init: function () {
            var self = this;
            if(!self.validateSpm()){
                if(confirm('页面还没有spm埋点，请参照文档“http://shuju.taobao.ali.com/klc/baike/baikeInfo.htm?id=30”说明先进行spm申请和埋点。')){
                    window.open('http://shuju.taobao.ali.com/klc/baike/baikeInfo.htm?id=30');
                }
                return;
            }
            self.buildTips();
            self.currentGoldLog = true;
        },
        validateSpm:function(){
            var ispass = false,
                _spmId = common.getSPMId().split(".");
            if(_spmId[0]&&_spmId[1]){
                ispass = true;
            }
            return ispass;
        },
        createTpl:function(s){
            return ['<inc class="udata-icon-' +
                s.status +
                '-circle ' +
                ICON_CLS +
                '" title="'+s.tips+'"></inc>'].join('');

        },
        buildTips:function(){
            var self = this;
            self.clear();
            $('[data-spm-click]').each(function(i,e){
                if($(e).data(DATA)){
                    var _target = $(e),
                        _data = _target.data(DATA);
                    self.filter(_data,function(html){
                        _target.addClass(CONTAINER_CLS);
                        _target.append(html);
                    });
                }
            });
        },
        filter: function (data,handle) {
            var self = this,
                index = 0;

            function matchReg(reg,str){
                return reg.test(str);
            }
            function getMatch(reg,str){
                return reg.exec(str)[1];
            }
            function ajaxValidate(str,handle){
                var _s = false;
                $.ajax({
                    url : validateApi,
                    dataType : 'html',
                    scriptCharset: 'utf-8',
                    data : {
                        bustypecode : str
                    },
                    success : function(s){
                        if(JSON.parse(s).success == 1){
                            _s = true;
                        }
                        handle({suc:_s})
                    }
                });
                return _s;
            }
            if(!matchReg(/^[^;=&]+=[^;=&]+(?:[;&][^;=&]+=[^;=&]+)+$/,data)){
                index = 1;
                handle(self.createTpl(STATUS[index]));
                return;
            }else if(!matchReg(/^gostr=([^;]+)/,data)){
                index = 10;
                handle(self.createTpl(STATUS[index]));
                return;
            }else if(!matchReg(/;locaid=([^;]+)/,data)){
                index = 20;
                handle(self.createTpl(STATUS[index]));
                return;
            }else {
                ajaxValidate(getMatch(/gostr=([^;]+)/,data),function(e){
                    if(!e.suc){
                        index = 11;
                        handle(self.createTpl(STATUS[index]));
                    }else if(!matchReg(/^d\d+$/,getMatch(/locaid=([^;]+)/,data))){
                        index = 21;
                        handle(self.createTpl(STATUS[index]));
                    }else{
                        handle(self.createTpl(STATUS[index]));
                    }
                });
            }
        },
        clear: function () {
            $('.udata-gold-tip,.udata-gold-icon').remove();
        }
    };
    this.goldLogValidate = goldLogValidate;
})(jQuery);
