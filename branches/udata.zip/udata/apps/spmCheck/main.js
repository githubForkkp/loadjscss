/**
 * author: oldj
 * blog: http://oldj.net
 */
(function () {

	var spm_link_checker = new SPMLinkChecker();
	$.namespace("UData.apps.spmChecker");
	UData.apps.spmChecker = {
		/**
		 * 插件窗口中按钮被点击时将调用这个方法
		 */
		run: function () {
			console.info("invalid click start!");
			spm_link_checker.run();
		},

		/**
		 * 在这个方法中清除页面上显示的额外元素
		 */
		stop: function () {
			console.log("invalid click end!");
			spm_link_checker.hide();
		}
	};

})();

