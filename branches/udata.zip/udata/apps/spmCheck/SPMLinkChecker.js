/**
 * author: oldj
 * blog: http://oldj.net
 */

(function () {

	function relativePath2AbsPAth(relative_path) {
		if (relative_path.indexOf("//") == 0) {
			return relative_path;
		}
		if (relative_path.indexOf("/") == 0) {
			return location.protocol + "//" + location.host + relative_path;
		}

		var pathname = location.pathname;
		var a = pathname.split("/");
		a[a.length-1] = relative_path;

		return location.protocol + "//" + location.host + a.join("/");
	}

	function Link(checker, node) {
		this.checker = checker;
		this.node = node;
		this.text = node.html().replace(/</g, "&lt;");

		var url = node.attr("href"); // 带有 spm 参数的最终 url
		if (!url.match(/^https?:\/\//)) {
			url = relativePath2AbsPAth(url);
		}
		this.url = url;
	}

	Link.prototype = {
		doCheck: function () {

			if (this.isToSkip()) {
				this.checker.checkEnd();
				return;
			}

			var _this = this;

			chrome.extension.sendMessage({
				type: "app_spmMarkInvalidLinks::open_tab",
				options: {
					url: this.url,
					selected: false
				}
			}, function (response) {
				_this.chkFinallUrl(response.tab_url || "");
			});

		},

		isToSkip: function () {
			var url = this.url;
			return !this.isSPMInUrl(url) || this.isLoginUrl(url);

		},

		isLoginUrl: function (url) {
			return url.match(/^https?:\/\/login\.(taobao|tmall)\.com/i);
		},

		chkFinallUrl: function (final_url) {
			this.final_url = final_url;
			if (this.isSPMInUrl(final_url) || this.isLoginUrl(final_url)) {
//				console.log([final_url, "OK!"]);
			} else {
				console.log(["-->", this.url, final_url, "Fail!!!"]);
				this.checker.foundBadLink(this);
			}
			this.checker.checkEnd();
		},

		/**
		 * 检查 url 是否带有 spm 参数
		 * @param url
		 */
		isSPMInUrl: function (url) {
			return !!url.match(/[\?&]spm=/);
		}
	};

	function SPMLinkChecker() {

		this.count = 0;
		this.queue = [];
		this.processing_tabs = 0;
		this.max_tabs_size = 5;

		this.init();
	}

	SPMLinkChecker.prototype = {
		init: function () {
			var _this = this;
//			this.rid = ("-udata-ext-spm-link-checker-" + Math.random()).replace(".", "");
//			this.ifr = $("<iframe name='" + this.rid + "' style='width:1px;height:1px;display:none;'></iframe>");
//			$("body").append(this.ifr);

			this.node_inform = $("<div class='-udata-ext-spm-link-checker-inform'></div>");
			$("body").append(this.node_inform);

			this.node_report = $("<div class='-udata-ext-spm-link-checker-report'></div>");
			$("body").append(this.node_report);
			$('body').delegate('.-udata-ext-spm-link-checker-report .-udata-ext-close','click.spmChecker',function(e){
				//$(".udata-valid-tool").trigger("click");
				_this.node_report.slideUp();
				//$('body').undelegate('click.spmChecker');
				return false;
			});
			// $(".-udata-ext-spm-link-checker-report .-udata-ext-close").on("click", function () {
			// 	_this.node_report.slideUp();
			// 	return false;
			// });
		},

		run: function () {
			var _this = this;
			this.bad_links = [];

			var links = $("a, area");
			var len = links.length;

			if (len > 300) {
				if (!confirm("共有 " + len + " 个待检查链接，这可能要花一些时间，继续吗？"
					+ "\n\n（检查过程中如果想中止，只需关闭或刷新当前页面）"
				)) {
					this.hide();
					return;
				}
			}

			this.start_time = (new Date()).getTime();

			links.each(function () {
				_this.check($(this));
			});

			this.intervalCheck();
			this.node_inform.fadeIn();
		},

		hide: function () {
			this.node_inform.hide();
			this.node_report.hide();
			this.node_report.html("");
		},

		foundBadLink: function (link) {
			this.bad_links.push(link);
		},

		inform: function () {

			var time = (new Date()).getTime() - this.start_time; // 已花费的时间
			var avg;
			var left;
			var left_str;

			if (this.count > 0) {
				avg = time / this.count;
				left = avg * this.queue.length;

				left = Math.floor(left / 1000); // 转换为秒

				if (left > 60) {
					left_str = Math.floor(left / 60) + "分" + (left % 60) + "秒";
				} else {
					left_str = left + "秒";
				}
			}

			this.node_inform.html([
				"<storng>SPM链接检测</storng> ",
				"已检测：",
				this.count,
				" / 剩余：",
				this.queue.length,
				" 发现问题：",
				this.bad_links.length,
				(left ? (" 预计剩余时间：" + left_str) : "")
			].join(""));
		},

		check: function (link) {

			this.queue.push(link);

			if (this.processing_tabs < this.max_tabs_size) {
				this.check2();
			}

		},

		check2: function () {

			var i;
			for (i = 0; i < this.max_tabs_size; i ++) {
				if (this.processing_tabs < this.max_tabs_size) {
					this.check3();
				}
			}

		},

		check3: function () {
			this.processing_tabs ++;

			var link = this.queue.shift();
			if (!link) {
				this.processing_tabs --;
				return;
			}

			var href = link.attr("href");
			if (!href) {
				this.processing_tabs --;
				return;
			}

			var evt = document.createEvent("MouseEvents");
			evt.initEvent("mousedown", true, true);
			link[0].dispatchEvent(evt);
			href = link.attr("href");

			var alink = new Link(this, link);

			alink.doCheck();
			this.count ++;
		},

		intervalCheck: function () {
			var _this = this;

			function chk() {

//				console.log([_this.queue.length, _this.processing_tabs]);

				if (!_this.processing_tabs && _this.queue.length > 0) {
					_this.check2();
				}

				if (_this.queue.length > 0) {
					setTimeout(chk, 1000);
				}
			}

			chk();
		},

		checkEnd: function () {
			this.processing_tabs --;
			this.inform();
			this.check2();

			if (this.queue.length == 0 && this.processing_tabs == 0) {
				this.report();
			}
		},

		report: function () {

			var _this = this;
			setTimeout(function () {
				_this.node_inform.fadeOut();
			}, 1000);

			var table = [
				"<a href='#' class='-udata-ext-close'>关闭</a>",
				"<h2>SPM参数跳转检查结果</h2>",
				"<table cellpadding='0' cellspacing='0'>",
				"<thead><tr><th>序号</th><th>链接</th><th>href</th><th>最终页面</th></tr></thead>",
				"<tbody>"
			];
			var i;
			var link;
			for (i = 0; i < this.bad_links.length; i ++) {
				link = this.bad_links[i];
				table = table.concat(["<tr>",
					"<td>" + (i + 1) + "</td>",
					"<td>" + link.text + "</td>",
					"<td><a href='" + link.url + "'>" + link.url + "</a></td>",
					"<td><a href='" + link.final_url + "'>" + link.final_url + "</a></td>",
					"</tr>"]);
			}

			table.push("</tbody></table>");

			this.node_report.html(table.join("")).slideDown();
		}


	};

	window.SPMLinkChecker = SPMLinkChecker;

})();
