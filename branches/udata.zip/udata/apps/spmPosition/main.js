/**
 * spm位置数据模块
 * @author : yu.yuy
 * @createTime : 2013-3-13
 */
(function(){
	$.namespace('UData.apps.spmPosition');
	var chunkTimer,
	common = UData.common,
    gold = UData.apps.goldLog,
    menu = UData.menu,
    spmHistory = UData.apps.spmHistory,
	chunk = function(array, process, context, callback){
		setTimeout(function(){
			var item = array.shift();
			process.call(context,item);
			if(array.length>0){
				chunkTimer = setTimeout(arguments.callee, 1);
			}
			else if(array.length===0 && $.isFunction(callback)){
				callback.call(context);
			}
		},1);
	},
	RandomClassName = function(){
		var a = ['udata-spm-position-odd','udata-spm-position-even'],
		flag = true;
		return {
			getCurrent : function(){
				flag = !flag;
				return a[+flag];
			},
			getAnother : function(){
				return a[+!flag];
			}
		};
	}(),
    magic = 0;

	UData.apps.spmPosition = {
		url: 'http://shuju.taobao.ali.com/rms/pub/spmPositionDateData.htm',
        // 注意：如果要改实时地址，就修改下面这个realDataUrl
        realDataUrl: 'http://pretdc.taobao.ali.com/rms/pub/UDataPositionRealData.htm',
		anchors : $.makeArray($('a,area,a:not(.ui-state-default)')),
		tipClassName : 'udata-spm-position-tip',
		quitMode : 'udata-spm-position-quit-mode',
		tipContainerClassName : 'udata-spm-position-tip-container',
		pageBody : $(document.body),
		udataMenu : null,
		getSpmPageId : function(){
			var spmPageId = common.getSPMId();
			return (spmPageId&&spmPageId.length)?spmPageId.join('.'):null;
		},
		getData : function(date, type){
			var that = this,
			    data = {
				    spmId : this.spmPageId
                };
			that.currentDate = date;

			if(common.loadingBox){
				common.loadingBox.show();
			}
			else{
				common.buildLoading();
			}
			if(date){
				data['date'] = date;
			}
			$.ajax({
				url : that.url,
				data : data,
				dataType : 'json'
			}).done(function(o){
				var data,
				date;
				if(!o){
					return;
				}
				if(o.success){
					data = o.data;
					date = o.date;
                    that.currentDate = date;
                    that.tpv = o.pv;
                    that.tuv = o.uv;
					that.maxDate = that.maxDate || o.maxDate;
					//停掉上一个日期数据进程
					clearTimeout(that.dynamicTimer);
					clearTimeout(chunkTimer);
					that.anchors = $.makeArray($('a,area'));
					that.currentStatusClassName = RandomClassName.getCurrent();
					that.switchStatusClassName(that.pageBody);
                    that.initDatepicker(date);
					that.dataMap = data;
                    that.type = type;
                    that.show();
				}
				else{
					if(o.message === '没有获取到对应数据'){
						that.getData((date?Date.parse(date).addDays(-1):Date.today().addDays(-2)).toString('yyyy-MM-dd'), type);
					} else {
                        alert(o.message);
                    }
				}
				common.loadingBox.hide();
			});
		},
        getRealData : function(date, type){
            var that = this,
                data = {
                    spmId : this.spmPageId
                };

            data['date'] = common.getDate();
            $.ajax({
                url : that.realDataUrl,
                data : data,
                dataType : 'json'
            }).done(function(o){
                    var data,
                        date;
                    if(!o){
                        return;
                    }
                    if(o.success){
                        data = o.data;
                        date = o.date;
                        that.currentDate = date;
                        that.tpv = o.pv;
                        that.tuv = o.uv;
                        that.maxDate = that.maxDate || o.maxDate;
                        //停掉上一个日期数据进程
                        clearTimeout(that.dynamicTimer);
                        clearTimeout(chunkTimer);
                        that.anchors = $.makeArray($('a,area'));
                        that.currentStatusClassName = RandomClassName.getCurrent();
                        that.dataMap = data;
                        that.type = type;
                        that.show();
                    }
                    else{
                        if(o.message === '没有获取到对应数据'){
                            that.getData((date?Date.parse(date).addDays(-1):Date.today().addDays(-2)).toString('yyyy-MM-dd'), type);
                        } else {
                            alert(o.message);
                        }
                    }
                });
        },
		gotoPreviousDay : function(el){
			var that = this,
			currentDate,
			yesterday,
            type = that.pageBody.hasClass('udata-spm-uv-pattern') ? "uv" : "pv";

			currentDate = that.calendar.datepicker("getDate");
			that.calendar.datepicker("hide");
 			yesterday = currentDate.addDays(-1).toString('yyyy-MM-dd');
 			that.getData(yesterday, type);
            common.setFakeDay(yesterday);
            menu.showPageData(yesterday);
		},
		gotoNextDay : function(){
			var that = this,
			currentDate,
			tomorrow,
            type = that.pageBody.hasClass('udata-spm-uv-pattern') ? "uv" : "pv";

			currentDate = that.calendar.datepicker("getDate");
			that.calendar.datepicker("hide");
 			tomorrow = currentDate.addDays(1).toString('yyyy-MM-dd');
 			that.getData(tomorrow, type);
            common.setFakeDay(tomorrow);
            menu.showPageData(tomorrow);
		},
        /*
		buildLoading : function(){
			var that = this;
			that.loadingBox = $('<div class="udata-spm-position-loading"></div>');
			that.loadingBox.appendTo(that.pageBody);
		}, */
		initDatepicker : function(date){
			var that = this;
			that.calendar.val(date);
			common.manageNextDay(that.nextDayBtn, date, that.maxDate);

			if(!that.hasBuildDatePicker){
				that.calendar.datepicker({
					defaultDate:date,
					maxDate : that.maxDate,
					dateFormat: "yy-mm-dd",
					onSelect : function(dateText, inst){
                        var type = that.pageBody.hasClass('udata-spm-uv-pattern') ? "uv" : "pv";
						if(that.currentDate === dateText){
							return;
						}
						that.getData(dateText, type);
                        common.setFakeDay(dateText);
                        menu.showPageData(dateText);
					}
				});
				that.hasBuildDatePicker = true;
                common.setFakeDay(date);
                menu.showPageData(date);
                that.calendar.siblings("ins.udata-date-overlay").show();
			}
		},
		isInUdataMenu: function(anchor) {
			var that = this;
			return $.contains(that.udataMenu[0],anchor);
		},
		isEmptyAnother: function(a) {
			var ret = false,
			href = $.trim(a.attr('href'));
			if(href==='#'||href.indexOf('javascript:void')>-1){
				ret = true;
			}
			return ret;
		},
		switchStatusClassName : function(el){
			var that = this,
			anotherClassName = RandomClassName.getAnother();
			if(el.hasClass(anotherClassName)){
				el.removeClass(anotherClassName);
			}
			el.addClass(that.currentStatusClassName);
		},
		show : function(){
			var that = this;
            // 处理黄金令箭
            gold.run(that.calendar, that.nextDayBtn, that.type, that.dataMap);
			chunk(that.anchors,that.showItemData,that,that.showDynamic);
		},
		showDynamic : function(){
			var that = this;
			that.isDynamic = true;
			that.dynamicTimer = setTimeout(function(){
				that.anchors = $.makeArray($('a:not([data-spm-anchor-id]),area:not([data-spm-anchor-id])'));
				that.show();
			}, 3000);
		},
		triggerCreateSpmId : function(anchor){
			var evt = document.createEvent("MouseEvents");
			evt.initMouseEvent("mousedown", true, true, document.defaultView, 0, 0, 0, 0, 0, false, false, true, false, 0, null);
			anchor.dispatchEvent(evt);
		},
		showItemData : function(item){
			var that = this,
			anchor = $(item),
			spmAnchorId;
			if(!item || that.isInUdataMenu(item) || that.isEmptyAnother(anchor)){
				return;
			}
			spmAnchorId = anchor.attr('data-spm-anchor-id');
			if(!spmAnchorId){
				that.triggerCreateSpmId(item);
				spmAnchorId = anchor.attr('data-spm-anchor-id');
				if(!spmAnchorId){
					return;
				}
			}
			if(!that.checkSpmCode(spmAnchorId)){
				return;
			}
			this.draw(anchor,spmAnchorId);
		},
		draw : function(el,spmAnchorId){
			var that = this,
			pv,
			uv,
            prate,
            urate,
            pvReal,
            uvReal,
			pvLabel = el.find('.udata-spm-pv'),
            pvRateLabel = el.find(".udata-spm-pv-rate"),
            pvRealLabel = el.find(".udata-spm-pv-real"),
			uvLabel = el.find('.udata-spm-uv'),
            uvRateLabel = el.find(".udata-spm-uv-rate"),
            uvRealLabel = el.find(".udata-spm-uv-real");
			if(that.dataMap[spmAnchorId]){
                if (!this.realMode) {
                    pv = that.dataMap[spmAnchorId]['pv'];
                    uv = that.dataMap[spmAnchorId]['uv'];
                    prate = that.tpv == 0 ? 0 : pv/that.tpv*100;
                    urate = that.tuv == 0 ? 0 : uv/that.tuv*100;

                    if(pvLabel.length){
                        pvLabel.html(pv).attr('title', pv);
                        that.switchStatusClassName(pvLabel);
                        pvRateLabel.html(prate.toFixed(2)+"%").attr('title', prate.toFixed(2)+"%");
                        that.switchStatusClassName(pvRateLabel);
                        uvLabel.html(uv).attr('title', uv);
                        that.switchStatusClassName(uvLabel);
                        uvRateLabel.html(urate.toFixed(2)+"%").attr('title', urate.toFixed(2)+"%");
                        that.switchStatusClassName(uvRateLabel);
                    } else {
                        el.addClass(that.tipContainerClassName).append(that.buildShowBox(pv,uv));
                    }
                } else {
                    pvReal = that.dataMap[spmAnchorId]['pv'];
                    //magic++;
                    uvReal = that.dataMap[spmAnchorId]['uv'];
                    //magic++;

                    var desLabel = that.pageBody.hasClass("udata-spm-uv-pattern") ? uvRealLabel : pvRealLabel;
                    if(pvRealLabel.length){
                        desLabel.animate({opacity: 0});
                        pvRealLabel.html(pv).attr('title', pvReal);
                        //that.switchStatusClassName(pvRealLabel);
                        uvRealLabel.html(uv).attr('title', uvReal);
                        //that.switchStatusClassName(uvLabel);
                        desLabel.animate({opacity: 1});
                    } else {
                        el.addClass(that.tipContainerClassName).append(that.buildShowBox(pvReal, uvReal));
                    }
                }
			}
			else{
				pvLabel.remove();
				uvLabel.remove();
			}
		},
		checkSpmCode : function(spmCode){
			var that = this,
			a = spmCode.split('.'),
			ret = true;
			for(var i=0,l=a.length;i<l;i++){
				if(a[i] === '0'){
					ret = false;
					break;
				}
			}
			return ret;
		},
		getDisplayLevel : function(data){
			var s = data.toString(),
			level = 1;
			switch(s.length){
				case 1:
					level = 8;
					break;
				case 2:
					level = 7;
					break;
				case 3:
					level = 6;
					break;
				case 4:
					level = 5;
					break;
				case 5:
					level = 4;
					break;
				case 6:
					level = 3;
					break;
				case 7:
					level = 2;
					break;
				default:
					level = 1;
			}
			return 'udata-spm-position-level-'+level;
		},
		buildShowBox : function(pv, uv){
			var ret = '';
            if (!this.realMode) {
                var prate = this.tpv == 0 ? 0 : pv/this.tpv*100,
                    urate = this.tuv == 0 ? 0 : uv/this.tuv*100;
                ret += this.buildDataLabel(pv, 'udata-spm-pv');
                ret += this.buildDataLabel(uv, 'udata-spm-uv');
                ret += this.buildDataLabel(pv, "udata-spm-pv-rate", prate.toFixed(2)+"%");
                ret += this.buildDataLabel(uv, "udata-spm-uv-rate", urate.toFixed(2)+"%");
                ret += this.buildDataDetail();
            } else {
                ret += this.buildDataLabel(pv, "udata-spm-pv-real");
                ret += this.buildDataLabel(uv, "udata-spm-uv-real");
            }
			return ret;
		},
		buildDataLabel : function(data, type, rate){
			var ret = '<ins class="',
                d = rate ? rate : data;
			ret += this.tipClassName;
			ret += ' '+this.getDisplayLevel(data);
			ret += ' '+type;
			ret += ' '+this.currentStatusClassName;
			ret += '" title="';
			ret += d;
			ret += '">';
			ret += d;
			ret += '</ins>';
			return ret;
		},
        buildDataDetail: function() {
            return '<ins class="udata-spm-checkmore" style="background:url('+chrome.extension.getURL("")+'apps/spmHistory/history.png)"></ins>';
        },
		switchCategory : function(type) {
			var that = this;
			that.pageBody[type==='uv'?'addClass':'removeClass']('udata-spm-uv-pattern');
            // 处理黄金令箭
            gold.run(that.calendar, that.nextDayBtn, type, that.dataMap);
		},
        // 用于与SPM模块统一时间
        setSyncDate: function(date) {
            this.currentDate = date;
        },
        getSyncDate: function() {
            return this.currentDate;
        },
		run: function(calendar, nextDayBtn, type, remain, isReal) {
			var that = this;
			that.calendar = calendar;
			that.nextDayBtn = nextDayBtn;

            if(that.isRunning && remain) {
                that.switchCategory(type);
                return;
            }

            that.isRunning = true;
			if(that.pageBody.hasClass(that.quitMode)){
				that.pageBody.removeClass(that.quitMode);
				if(that.spmPageId) {
                    that.switchCategory(type);
                    if (isReal) {
                        that.realDataStartup();
                    } else {
                        that.getData(that.currentDate, type);
                    }
				}
				return;
			}

			that.udataMenu = $('#udataMenu');
			that.spmPageId = that.spmPageId || common.getSPMId();
			if(!that.spmPageId || that.spmPageId==='0.0' || that.spmPageId==='0.0.0'){
				return;
			}
            if (isReal) {
                that.realDataStartup();
            } else {
                that.getData(null, type);
            }
		},
		stop: function(remain) {
			var that = this;
            spmHistory.dialogModule.hide();
			clearTimeout(this.dynamicTimer);
			clearTimeout(chunkTimer);

            if (!remain) {
                that.pageBody.addClass(this.quitMode);
                that.calendar.datepicker("hide");
			    that.calendar.datepicker('destroy');
                that.calendar.siblings("ins.udata-date-overlay").hide();
                that.hasBuildDatePicker = false;
                that.calendar.val('');
                that.isRunning = false;
            }
            // 停止黄金令箭
            gold.stop();
		},
        hideDatepicker: function() {

            $(".udata-previous-day-btn").addClass("udata-day-btn-disabled");
            if ($(".udata-next-day-btn").hasClass("udata-day-btn-disabled")) {
                $(".udata-next-day-btn").data("isDisabled", true);
            } else {
                $(".udata-next-day-btn").addClass("udata-day-btn-disabled");
            }
            $(".udata-calendar-mask").show();
        },
        showDatepicker: function() {
            $(".udata-previous-day-btn").removeClass("udata-day-btn-disabled");
            if (!$(".udata-next-day-btn").data("isDisabled")) {
                $(".udata-next-day-btn").removeClass("udata-day-btn-disabled");
            }
            $(".udata-calendar-mask").hide();
        },
        realDataStartup: function(type) {
            var that = this,
                type = that.pageBody.hasClass("udata-spm-uv-pattern") ? "uv" : "pv";
            that.realMode = true;
            that.pageBody.addClass("udata-spm-real-mode");
            that.hideDatepicker();
            that.getRealData(null, type);
            console.log("tt");
            that.realTimer = setTimeout(function() {
                clearTimeout(that.realTimer);
                that.realTimer = null;
                // 开始执行
                that.realDataStartup();
            }, 60000);
        },
        realDataShutdown: function() {
            this.realMode = false;
            this.pageBody.removeClass("udata-spm-real-mode");
            this.showDatepicker();
            clearTimeout(this.realTimer);
            this.realTimer = null;
        }
	};
}).call(this);