/**
 * 页面数据模块
 * @author : gonghao.gh
 * @createTime : 2013-07-24
 */
(function ($) {
    $.namespace('UData.apps.pageData');

    var common = UData.common,
        pageBody = $(document.body),
        url = 'http://shuju.taobao.ali.com/rms/pub/spmPageHistoryData.htm';

    UData.apps.pageData = {
        init: function() {
            this.initDialog();
            this.buildMask();
            this.bindEvent();
            this.loading = this.dialogModule.find(".udata-pageData-loading");
            this.loading.css('background', 'url("'+chrome.extension.getURL("")+'apps/spmHistory/loading.gif") no-repeat 330px 105px');
            this.container = this.dialogModule.find(".udata-pageData-container");
            this.fail = this.dialogModule.find(".udata-pageData-fail");
        },

        initDialog: function() {
            if (!this.dialogModule) {
                var myModule =
                    '<div class="udata-pageData-module">' +
                        '<div class="udata-pageData-header"><span class="udata-pageData-title">页面流量</span><a href="javascript:void(0);" class="udata-pageData-close-btn">关闭</a></div>' +
                        '<div class="udata-pageData-body">' +
                            '<div class="udata-pageData-loading"></div>' +
                            '<div id="udata-pageData-container" class="udata-pageData-container"></div>' +
                        '</div>' +
                        '<div class="udata-pageData-fail"></div>' +
                        '</div>' +
                    '</div>';
                this.dialogModule = $(myModule);
                this.dialogModule.appendTo(pageBody).hide();
            }
        },

        bindEvent: function() {
            var self = this;
            $(".udata-pageData-close-btn").on("click", function() {
                self.closeDialog();
                return false;
            });
        },

        // 没有复用spmPosition中的loading，因为它在某处被隐藏了
        buildMask: function() {
            this.maskBox = $('<div class="udata-pageData-mask"></div>');
            this.maskBox.appendTo(pageBody);
        },

        closeDialog: function() {
            $(".udata-page-click-more").trigger("click");
        },

        showChart: function(res) {
            if (!res) {
                return;
            }
            if (res.success) {
                var data = res.data,
                    categories = data.history.date.map(function(date, i) {
                        return date.substring(5);
                    });
                var param = {
                    id: "udata-pageData-container",
                    series: [
                        {name: "pv", data: data.history.pv.data, yAxis: data.history.pv.yAxis},
                        {name: "uv", data: data.history.uv.data, yAxis: data.history.uv.yAxis},
                        {name: "引导IPV", data: data.history.directIpv.data, yAxis: data.history.directIpv.yAxis},
                        {name: "引导IPV_UV", data: data.history.directIpvUv.data, yAxis: data.history.directIpvUv.yAxis},
                        {name: "引导支付宝金额", data: data.history.directAliFee.data, yAxis: data.history.directAliFee.yAxis},
                        {name: "引导支付宝笔数", data: data.history.directAliCnt.data, yAxis: data.history.directAliCnt.yAxis},
                        {name: "引导间接支付宝金额", data: data.history.allAliFee.data, yAxis: data.history.allAliFee.yAxis},
                        {name: "引导间接支付宝笔数", data: data.history.allAliCnt.data, yAxis: data.history.allAliCnt.yAxis},
                        {name: "引导支付宝UV", data: data.history.directAliUv.data, yAxis: data.history.directAliUv.yAxis},
                        {name: "引导间接支付宝UV", data: data.history.allAliUv.data, yAxis: data.history.allAliUv.yAxis}
                    ]
                };
                if (!this.chartConstruct) {
                    this.makeLineChart(param, categories);
                } else {
                    this.updateLineChart(param, categories);
                }
                this.container.show();
            } else {
                this.fail.html(res.message).show();
            }
            this.loading.hide();
        },

        makeLineChart: function(param, categories) {
            $('#'+param.id).highcharts({
                chart: {
                    defaultSeriesType: 'spline',
                    width: 700
                },
                credits: {
                    text: ""
                },
                title: {
                    text: ''
                },
                xAxis: {
                    categories: categories
                },
                yAxis: [{
                    title: '',
                    min: 0,
                    labels: {
                        formatter: function() {
                            return this.value;
                        }
                    }
                }, {
                    title: '',
                    min: 0,
                    opposite: true,
                    labels: {
                        formatter: function() {
                            return this.value;
                        }
                    }
                }],
                tooltip: {
                    formatter: function() {
                        var showNum = Highcharts.numberFormat(this.y, 0);
                        return '<b>'+ this.x +'</b><br/>'+
                            this.series.name +': '+ showNum;
                    }
                },
                series: param.series
            });
            this.chartConstruct = true;
        },

        updateLineChart: function(param, categories) {
            var data = [],
                chart = $('#'+param.id).highcharts();
            chart.xAxis[0].categories = categories;
            for (var j = 0, length = param.series.length; j < length; j++) {
                chart.series[j].setData(param.series[j].data);
            }
        },

        run: function() {
            var self = this,
                spmId = common.getSPMId(),
                curDate = $(".udata-calendar").datepicker("getDate"),
                startInt = -6 - (curDate ? 0 : 1),
                endInt = 0 - (curDate ? 0 : 1),
                startDate = common.getDate(curDate, startInt),
                endDate = common.getDate(curDate, endInt);

            this.maskBox.show();
            this.dialogModule.show();

            var data = {
                spmId: spmId,
                startDate: startDate,
                endDate: endDate
            };

            $.ajax({
                url: url,
                data: data,
                dataType: "json",
                success: function(json) {
                    //console.log(json);
                    self.showChart(json);
                },
                error: function() {
                    console.log("error");
                }
            });
            console.log("pageData run");
        },

        stop: function() {
            this.dialogModule.hide();
            this.maskBox.hide();
            console.log("pageData stop");
        }
    };

    UData.apps.pageData.init();
})(jQuery);