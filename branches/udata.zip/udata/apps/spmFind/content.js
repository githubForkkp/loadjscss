/**
 * author: oldj
 * blog: http://oldj.net
 */

(function () {

	$("span.udata-ars_position_icon").each(function () {
		var url = $(this).attr("url");
		var spmid = $(this).attr("spmid");

		var new_node = $(this).clone();
		$(this).after(new_node).remove();
		new_node.click(function () {

			console.log([url, spmid]);
			chrome.extension.sendMessage({
				type: "app_spmFind::open_tab",
				options: {
					url: url,
					selected: true
				},
				data: {
					hl_spm_id: spmid
				}
			}, function (response) {
				console.log(response);
			});

			console.log("~~~");

			return false;
		});
	});

	chrome.extension.sendMessage({
		type: "app_spmFind::tab_opened"
	}, function (response) {

		var hl_spm_id = response.data.hl_spm_id;

		function hightLight() {
			// 高亮 hl_spm_id
			APP_spmFind.app.obj_ipt.val(hl_spm_id);
			if (!APP_spmFind.app.search()) {
				// 如果没有找到，则滚动滚动条再找一次
				scrollPage(function () {
					APP_spmFind.app.search();
				});
			}
		}

		if (hl_spm_id) {
			APP_spmFind.start();
			hightLight();
		}
	});

	/**
	 * 滚动页面到底部，再滚回顶部，以便加载懒加载的部分
	 * @param callback {Function}
	 */
	function scrollPage (callback) {
		var y = 0;
		var step = 100;
		window.scrollTo(0, 0);

		function f() {
			if (y < document.body.scrollHeight) {
				y += step;
				window.scrollTo(0, y);
				setTimeout(f, 50);
			} else {
				window.scrollTo(0, 0);

				if (typeof callback == "function") {
					callback();
				}
			}
		}

		setTimeout(f, 1000);
	}
})();
