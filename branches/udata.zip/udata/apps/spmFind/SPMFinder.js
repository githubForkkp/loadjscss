/**
 * author: oldj
 * blog: http://oldj.net
 */

(function () {

	function SPMFinder() {

		this.matches = [];

		this.init();
	}

	SPMFinder.prototype = {
		init: function () {
			this.obj = $([
				"<div id='udata-ext-spm-finder'>",
				"<h3>",
				"<span class='close'><a href='#'>关闭</a></span>",
				"定位SPM资源位</h3>",
				"<div class='udata-ext-block'>",
				"<input type='text' id='udata-ext-spm-finder-spm-id' placeholder='请输入要查询的SPM ID，形如“a.b.c.d”的格式'>",
				"<button>查找</button>",
				"</div>",
				"<div class='udata-ext-block' id='udata-ext-spm-finder-result'>",
				"</div>",
				"</div>"
			].join(""));

			this.obj_ipt = this.obj.find("input[type=text]");
			this.obj_btn = this.obj.find("button");
			this.obj_result = this.obj.find("#udata-ext-spm-finder-result");

//			this.obj.drags();

			var _this = this;

			this.obj.find("span.close a").click(function () {
                $("dt.udata-position-tool").trigger("click");
				return false;
			});

			var _doSearch = function () {
				_this.search();
			};
			this.obj_btn.click(_doSearch);
			this.obj_ipt.keyup(function (e) {
				if (e.keyCode == 13) _doSearch();
			});

			$("#udataMenu").append(this.obj);
		},

		/**
		 * 判断一个url是否匹配指定的spm
		 * @param url {String}
		 * @param spm {String}
		 * @param is_struct
		 */
		isMatch: function (url, spm, is_struct) {
			if (!url) return false;
			if (!is_struct) {
				return url && url.indexOf(spm) != -1;
			}

			var spm_in_url = url.match(/spm=([\w\.]+)/);
			if (!spm_in_url) return false;

			spm_in_url = spm_in_url[1].split(".");
			spm = spm.split(".");

			var i;
			var l;
			for (i = 0, l = spm.length; i < spm.length; i ++) {
				if (spm[i] != spm_in_url[i]) return false;
			}

			return true;
		},

		try2find: function (spm) {
			var _this = this;
//			var spm_str = "?spm=" + spm;

			$("a, area").each(function () {
				var link = $(this);

				var evt = document.createEvent("MouseEvents");
				evt.initEvent("mousedown", true, true);
				link[0].dispatchEvent(evt);
				var href = link.attr("href");

				if (_this.isMatch(href, spm, true)) {
					_this.found(link);
				} else {
					_this.notMatch(link);
				}
			});
		},

		found: function (link) {
			link.addClass("udata-ext-hightlight");
			this.matches.push(link);
		},

		notMatch: function (link) {
			link.removeClass("udata-ext-hightlight");
		},

		search: function () {
			var spm_id = this.obj_ipt.val();
			spm_id = spm_id.replace(/^\s+|\s+$/g, "").split(".").slice(0, 4);

			this.matches = [];
			this.try2find(spm_id.join("."));
			this.scrollToMatch();
			this.showSummary();

			return this.matches.length > 0;
		},

		scrollToMatch: function () {
			if (this.matches.length == 0) return;

			var match = this.matches[0];

			match[0].scrollIntoView();
//			var _this = this;
			setTimeout(function () {
				match.removeClass("-spm-ext-module-normal");
				match.removeClass("-spm-ext-module-local");
				match.addClass("animated shake");
			}, 500);

			setTimeout(function () {
				match.removeClass("animate shake");
			}, 3000);
		},

		showSummary: function () {
			this.obj_result.html([
				"共找到 " + this.matches.length + " 个匹配的资源位。"
			].join(""));
		},

		show: function () {
			this.obj.show();
			this.obj_ipt.focus();
		},

		hide: function () {
			var _this = this;
			this.matches.forEach(function (link) {
				_this.notMatch(link);
			});
			this.matches = [];
			this.obj.hide();
		}
	};

	window.SPMFinder = SPMFinder;

})();
