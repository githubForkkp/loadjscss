/**
 * author: oldj
 * blog: http://oldj.net
 */
(function () {

	var spm_finder;
    $.namespace("UData.apps.spmFinder");
    UData.apps.spmFinder = {
		/**
		 * 插件窗口中按钮被点击时将调用这个方法
		 */
		run: function () {
			console.info("spm find start!");

			if (!spm_finder) {
				spm_finder = new SPMFinder();
				//APP_spmFind.app = spm_finder;
			}

			spm_finder.show();
		},

		/**
		 * 在这个方法中清除页面上显示的额外元素
		 */
		stop: function () {
			console.log("spm find end!");

			spm_finder && spm_finder.hide();
		}

	};

})();
