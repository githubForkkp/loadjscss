/**
 * spm位置历史数据模块
 * @author : gonghao.gh
 * @createTime : 2013-07-17
 */
(function($){
    $.namespace('UData.apps.spmHistory');

    var common = UData.common,
        pageBody = $(document.body),
        dialogWidth = 550,
        padding = 50,
        url = 'http://shuju.taobao.ali.com/rms/pub/spmPositionHistoryData.htm';

    UData.apps.spmHistory = {

        init: function() {
            this.initDialog();
            this.loading = this.dialogModule.find(".udata-history-loading");
            this.container = this.dialogModule.find(".udata-history-container");
            this.fail = this.dialogModule.find(".udata-history-fail");
            this.bindEvent();
            this.chartConstruct = false;
            this.title = $('<li class="title"><p>链接明细地址</p><p>点击数</p><p>点击UV</p></li>');
            this.charts = [];
            this.loading.css('background', 'url("'+chrome.extension.getURL("")+'apps/spmHistory/loading.gif") no-repeat 245px 145px');
        },

        initDialog: function() {
            if (!this.dialogModule) {
                var myModule =
                    '<div class="udata-history-module">' +
                        '<div class="udata-history-header"><span class="udata-history-title">点击详情</span><a href="javascript:void(0);" class="udata-history-close-btn">关闭</a></div>' +
                        '<div class="udata-history-body">' +
                            '<div class="udata-history-loading"></div>' +
                            '<div class="udata-history-container">' +
                                '<ul class="udata-history-nav">' +
                                    '<li class="active" data-index="udata-history-click-data"><a href="javascript:void(0);">点击数据</a></li>' +
                                    '<li data-index="udata-history-guide-data"><a href="javascript:void(0);">引导数据</a></li>' +
                                    '<li data-index="udata-history-anchors"><a href="javascript:void(0);">点击链接</a></li>' +
                                '</ul>' +
                                '<ul class="udata-history-content">' +
                                    '<li id="udata-history-click-data" class="active">' +
                                        '<div id="udata-history-click-chart"></div>' +
                                    '</li>' +
                                    '<li id="udata-history-guide-data">' +
                                        '<div id="udata-history-guide-chart"></div>' +
                                    '</li>' +
                                    '<li id="udata-history-anchors">' +
                                        '<ul class="udata-history-anchor-list">' +
                                            '<li class="title"><p>链接明细地址</p><p>点击数</p><p>点击UV</p></li>' +
                                        '</ul>' +
                                    '</li>' +
                                '</ul>' +
                            '</div>' +
                            '<div class="udata-history-fail"></div>'
                        '</div>' +
                    '</div>';
                this.dialogModule = $(myModule);
                this.dialogModule.appendTo(pageBody).hide();
            }
        },

        bindEvent: function() {
            var self = this;

            $(document).delegate('.udata-spm-checkmore', 'click', function(e) {
                var $target = $(e.target),
                    a_container = $target.closest(".udata-spm-position-tip-container")[0],
                    pos = self.findSuitablePos(e.pageX+6, e.pageY+6, a_container),
                    spmId = a_container.getAttribute("data-spm-anchor-id"),
                    origText = $.trim(a_container.firstChild.nodeValue),
                    title = origText ? origText+"点击详情" : "点击详情",
                    curDate = $(".udata-calendar").datepicker("getDate"),
                    startDate = common.getDate(curDate, -6),
                    endDate = common.getDate(curDate);

                self.fail.hide();
                self.container.hide();
                $(".udata-history-title").text(title);
                // 参数传递
                var data = {
                    //callback: "func",
                    spmId: spmId,
                    startDate: startDate,
                    endDate: endDate,
                    _: new Date().getTime()
                };

                self.dialogModule.css({"left":pos.left, "top":pos.top}).show();
                self.loading.show();
                self.container.hide();
                $.ajax({
                    url: url,
                    data: data,
                    dataType: "json",
                    success: function(json) {
                        //console.log(json);
                        self.showChart(json);
                    },
                    error: function() {
                        console.log("error");
                    }
                });

                $(document).one('click', function() {
                    self.dialogModule.fadeOut();
                });
                return false;
            });

            this.dialogModule.on("click", function() {
                return false;
            });

            $(".udata-history-close-btn").on("click", function() {
                self.closeDialog();
                return false;
            });

            $(".udata-history-nav").on("click", "li", function(e) {
                var $target = $(e.target);
                if (!$target.hasClass("active")) {
                    $(".active", ".udata-history-nav").removeClass("active");
                    $(".active", ".udata-history-content").removeClass("active");
                    var contentId = $(this).addClass("active").data("index");
                    $("#"+contentId).addClass("active");
                }
                return false;
            });
        },

        findSuitablePos: function(left, top, target) {
            var pos = target.getBoundingClientRect(),
                totalWidth = document.documentElement.offsetWidth,
                desLeft = left;

            if (pos.left+dialogWidth+padding > totalWidth) {
                desLeft = left-(dialogWidth-pos.width);
            }
            return {left: desLeft+"px", top: top+"px"};
        },

        closeDialog: function() {
            this.dialogModule.fadeOut('normal', function() {
                $(".udata-history-nav").find("li").eq(0).trigger("click");
            });
        },

        showChart: function(res) {
            if (!res) {
                return;
            }
            if (res.success) {
                var data = res.data,
                    list = [],
                    categories = data.history.date.map(function(date, i) {
                        return date.substring(5);
                    });
                // 添加url信息
                for (var i = 0, l = data.anchorList.length; i < l; i++) {
                    var anchor = data.anchorList[i];
                    list.push('<li><p title="'+anchor.url+'">'+anchor.url+'</p><p>'+anchor.pv+'</p><p>'+anchor.uv+'</p></li>');
                }
                this.container.find(".udata-history-anchor-list").empty().append(this.title).append($(list.join("")));
                // 添加图表信息
                var params = [{
                    id: "udata-history-click-chart",
                    series: [
                        {name: "pv", data: data.history.pv.data, yAxis: data.history.pv.yAxis},
                        {name: "uv", data: data.history.uv.data, yAxis: data.history.uv.yAxis}
                    ]
                }, {
                    id: "udata-history-guide-chart",
                    series: [
                        {name: "引导IPV", data: data.history.directIpv.data, yAxis: data.history.directIpv.yAxis},
                        {name: "引导IPV_UV", data: data.history.directIpvUv.data, yAxis: data.history.directIpvUv.yAxis},
                        {name: "引导支付宝金额", data: data.history.directAliFee.data, yAxis: data.history.directAliFee.yAxis},
                        {name: "引导支付宝笔数", data: data.history.directAliCnt.data, yAxis: data.history.directAliCnt.yAxis},
                        {name: "引导间接支付宝金额", data: data.history.allAliFee.data, yAxis: data.history.allAliFee.yAxis},
                        {name: "引导间接支付宝笔数", data: data.history.allAliCnt.data, yAxis: data.history.allAliCnt.yAxis},
                        {name: "引导支付宝UV", data: data.history.directAliUv.data, yAxis: data.history.directAliUv.yAxis},
                        {name: "引导间接支付宝UV", data: data.history.allAliUv.data, yAxis: data.history.allAliUv.yAxis}
                    ]
                }];
                if (!this.chartConstruct) {
                    this.makeLineChart(params, categories);
                } else {
                    this.updateLineChart(params, categories);
                }
                this.container.show();
            } else {
                this.fail.html(res.message).show();
            }
            this.loading.hide();
        },

        makeLineChart: function(params, categories) {
            for (var i = 0, l = params.length; i < l; i++) {
                var param = params[i];
                $('#'+param.id).highcharts({
                    chart: {
                        defaultSeriesType: 'spline',
                        width: 515
                    },
                    credits: {
                        text: ""
                    },
                    title: {
                        text: ''
                    },
                    xAxis: {
                        categories: categories
                    },
                    yAxis: [{
                        title: '',
                        min: 0,
                        labels: {
                            formatter: function() {
                                return this.value;
                            }
                        }
                    }, {
                        title: '',
                        min: 0,
                        opposite: true,
                        labels: {
                            formatter: function() {
                                return this.value;
                            }
                        }
                    }],
                    tooltip: {
                        formatter: function() {
                            var showNum = Highcharts.numberFormat(this.y, 0);
                            return '<b>'+ this.x +'</b><br/>'+
                                this.series.name +': '+ showNum;
                        }
                    },
                    series: param.series
                });
                // 缓存chart对象，用于更新
                this.charts.push($('#'+param.id).highcharts());
            }
            this.chartConstruct = true;
        },

        updateLineChart: function(params, categories) {
            for (var i = 0, l = params.length; i < l; i++) {
                var param = params[i], data = [];
                this.charts[i].xAxis[0].categories = categories;
                for (var j = 0, length = param.series.length; j < length; j++) {
                    this.charts[i].series[j].setData(param.series[j].data);
                }
            }
        }
    };

    UData.apps.spmHistory.init();
})(jQuery);