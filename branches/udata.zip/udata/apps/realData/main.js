/**
 * 实时数据模块
 * @author: gonghao.gh
 * @createTime: 2013-08-13
 */
(function($){
    $.namespace("UData.apps.realData");

    var common = UData.common,
        menu = UData.menu,
        pageBody = $(document.body),
        loginUrl = "http://spm.alibaba-inc.com/spm/spmRules.htm",
        userUrl = "http://spm.alibaba-inc.com/spm/getCurrentUserInfo.json",
        rightUrl = "http://shuju.taobao.ali.com/rms/pub/spmAuthority.htm",
        ju_overviewUrl = "http://rc.ju.taobao.com:9999/json/dataJson.htm?ids={{id}}&type=item&fields=alipay,order,count,buyuv,pv,uv",
        ju_detailUrl = "http://rc.ju.taobao.com:9999/json/curveJson.htm?calcType=tot&showPredict=false&&startTime={{date}}&stopTime={{date}}&today=true&id={{id}}&columns={{type}}&type=item",
        // 注意：如果要改实时地址，就修改下面这个detailUrl
        detailUrl = "http://pretdc.taobao.ali.com/rms/pub/uDataPageRealData.htm?spmId={{spmId}}&date={{date}}&item={{type}}",
        waiter;

    UData.apps.realData = {

        config: {
            // 通用名单
            whiteList: ["taobao.com", "tmall.com"],
            // 通用接口
            universeInterface: function(search, key) {
                var params = common.url2obj(search);
                return params[key];
            }
            // 特殊接口
        },

        addEvent: function() {
            var that = this;

            that.dialogModule.on('click', "input[type=radio]", function() {
                var el = $(this),
                    type = el.data("type");
                if (type == that.type) {
                    return;
                } else {
                    el.prop("checked", "checked");
                    that.type = type;
                    that.getOverviewData();
                    that.getDetailData();
                    that.waitForBuild();
                }
            });

            // 关闭按钮
            that.dialogModule.on("click", ".udata-realData-close-btn", function() {
                // trigger的时候会触发两次，原因不明，暂时手动调用
                menu.manualStop();
                return false;
            });
        },

        autoLogin: function() {
            var that = this,
                login_ifr = document.createElement("iframe"),
                flag = true;
            login_ifr.src = loginUrl;
            login_ifr.style.display = "none";
            login_ifr.onload = function () {
                if (flag) {
                    flag = false;
                    that.getUserInfo();
                    try {
                        document.removeChild(login_ifr);
                    } catch (e) {}
                }
            };
            document.body.appendChild(login_ifr);
        },

        getUserInfo: function() {
            var that = this;
            $.ajax({
                url: userUrl,
                data: {_: +new Date()},
                dataType: "json",
                success: function(res) {
                    var empIdStr = res.result.empId.toString(),
                        empId = "";
                    for (var i = 0, l = 6-empIdStr.length; i < l; i++) {
                        empId += "0";
                    }
                    empId += empIdStr;
                    that.getUserRight(empId, 13522, false);
                }
            })
        },

        getUserRight: function(empId, roleId, debug) {
            var that = this;
            if (debug) {
                that.buildRealChart();
                that.getOverviewData();
                that.getDetailData();
                that.waitForBuild();
            } else {
                $.ajax({
                    url: rightUrl,
                    data: {workId: empId, roleId: roleId, _: +new Date()},
                    dataType: "json",
                    success: function(res) {
                        if (res.success == true) {
                            if (res.hasRight) {
                                that.buildRealChart();
                                that.getOverviewData();
                                that.getDetailData();
                                that.waitForBuild();
                            } else {
                                alert(
                                    "您没有相关的数据查看权限，权限申请地址为：\n"+
                                    "http://wf.alibaba-inc.com/new/smartflow/default/index?requesttypename=c_data_proj\n"+
                                    "项目名：uData"
                                );
                                menu.manualStop();
                            }
                        } else {
                            alert(res.message);
                            menu.manualStop();
                        }
                    }
                });
            }
        },

        buildRealChart: function() {
            if (!this.dialogModule) {
                var myModule =
                    '<div class="udata-realData-module">' +
                        '<div class="udata-realData-header"><span class="udata-realData-title"></span><a href="javascript:void(0);" class="udata-realData-close-btn">关闭</a></div>' +
                        '<div class="udata-realData-body">' +
                        '<div class="udata-realData-loading"></div>' +
                        '<div id="udata-realData-container" class="udata-realData-container">' +
                        '<ul class="udata-realData-radioGroup">' +
                        '<li><label><input type="radio" checked="checked" name="udata-realData-type" data-type="pv"/>当日累计PV：</label><span class="udata-realData-pv"></span></li>' +
                        '<li><label><input type="radio" name="udata-realData-type" data-type="uv"/>当日累计UV：</label><span class="udata-realData-uv"></span></li>';

                    if (this.isJuhuasuan) {
                        myModule += '<li><label><input type="radio" name="udata-realData-type" data-type="alipay"/>当日累计支付金额：</label><span class="udata-realData-alipay"></span></li>' +
                                    '<li><label><input type="radio" name="udata-realData-type" data-type="order"/>当日累计支付笔数：</label><span class="udata-realData-order"></span></li>';
                    }
                    myModule +=
                        '</ul>' +
                        '<div id="udataRealDataChart" class="udata-realData-chart"></div>' +
                        '</div>' +
                        '</div>' +
                        '<div class="udata-realData-fail"></div>' +
                        '</div>' +
                        '</div>';
                this.dialogModule = $(myModule);
                this.dialogModule.appendTo(pageBody).hide();
                this.loading = this.dialogModule.find(".udata-realData-loading");
                this.loading.css('background', 'url("'+chrome.extension.getURL("")+'apps/spmHistory/loading.gif") no-repeat 440px 105px');
                this.container = this.dialogModule.find(".udata-realData-container");
                this.fail = this.dialogModule.find(".udata-realData-fail");

                this.addEvent();
            }
            $(".udata-pageData-mask").show();
            this.buildTitle();
            this.dialogModule.show();
            this.type = "pv";
        },

        buildTitle: function() {
            var today = common.getDate(),
                title = document.title,
                text = today + "&nbsp;&nbsp;&nbsp;&nbsp;" + title;

            this.dialogModule.find(".udata-realData-title").html(text);
        },

        getOverviewData: function() {
            var that = this,
                url = common.simpleTpl(ju_overviewUrl, {id: that.getItemId()});

            if (that.isJuhuasuan) {
                $.get(url, {callback: "a"}, function(res) {
                    var overviewData = that.jsonp2json(res);
                    that.overviewData = overviewData;
                    that.overviewReady = true;
                });
            } else {
                that.overviewReady = true;
            }
        },

        jsonp2json: function(res) {
            var str = $.trim(res),
                jsonstr = str.substring(2, str.length-1);
            return JSON.parse(jsonstr);
        },

        getItemId: function() {
            return this.config.universeInterface(location.search, "item_id");
        },

        getDetailData: function() {
            var that = this,
                type = that.type,
                url;
            if (that.isJuhuasuan) {
                url = common.simpleTpl(ju_detailUrl, {id: that.getItemId(), type: type, date: common.getDate()});
            } else {
                url = common.simpleTpl(detailUrl, {spmId: common.getSPMId(), type: type, date: common.getDate()});
            }

            $.get(url, null, function(res) {
                var key = that.isJuhuasuan ? "currData" : "data";
                that.detailData = that.parseData(res, key);
                if (that.lastLength) {
                    that.latests = that.detailData.slice(that.lastLength);
                } else {
                    that.latests = [];
                }
                that.lastLength = that.detailData.length;

                if (!that.isJuhuasuan) {
                    that.overviewData = [{pv: res.pv, uv: res.uv}];
                }

                that.detailReady = true;
            }, "json");
        },

        parseData: function(d, key) {
            var data = d[key],
                res = [];
            for (var i = 0, l = data.length; i < l; i++) {
                res.push({x: data[i][0], y: data[i][1]});
            }
            return res;
        },

        waitForBuild: function(isReal, series) {
            var that = this;
            waiter = setTimeout(function() {
                if (that.overviewReady && that.detailReady) {
                    clearTimeout(waiter);
                    waiter = null;
                    that.overviewReady = false;
                    that.detailReady = false;
                    that.updateOverview();
                    if (isReal) {
                        for (var i = 0, l = that.latests.length; i < l; i++) {
                            var latest = that.latests[i];
                            series.addPoint([latest.x, latest.y], true, true);
                        }
                        that.latests = [];
                    } else {
                        if (!that.chartConstruct) {
                            that.makeLineChart();
                        } else {
                            that.updateLineChart();
                        }
                        // 显示出来
                        that.container.show();
                        that.loading.hide();
                    }
                } else {
                    that.waitForBuild();
                }
            }, 50);
        },

        updateOverview: function() {
            var d = this.overviewData[0] || this.overviewData;
            $(".udata-realData-pv").text(common.numFormat(d.pv));
            $(".udata-realData-uv").text(common.numFormat(d.uv));
            if (this.isJuhuasuan) {
                $(".udata-realData-alipay").text(common.numFormat(d.alipay/100));
                $(".udata-realData-order").text(common.numFormat(d.order));
            }
        },

        makeLineChart: function() {
            var that = this;

            Highcharts.setOptions({global:{useUTC : false}});
            $('#udataRealDataChart').highcharts({
                chart: {
                    width: 890,
                    zoomType: 'x',
                    type: 'spline',
                    events: {
                        load: function() {
                            var series = this.series[0];
                            that.realTimer = setInterval(function() {
                                that.requestRealData(series);
                            }, 60000);
                        }
                    }
                },
                credits: {
                    text: ""
                },
                title: {
                    text: ''
                },
                xAxis: {
                    type: 'datetime',
                    title: {
                        text: null
                    }
                },
                yAxis: {
                    title: {
                        text: ''
                    },
                    min: 0
                },
                tooltip: {
                    shared: true
                },
                legend: {
                    enabled: false
                },
                plotOptions: {
                    spline: {
                        turboThreshold: 2000,
                        lineWidth: 2,
                        states: {
                            hover: {
                                enabled: true,
                                lineWidth: 3
                            }
                        },
                        marker: {
                            enabled: false,
                            states: {
                                hover: {
                                    enabled : true,
                                    radius: 5,
                                    lineWidth: 1
                                }
                            }
                        }
                    }
                },
                series: [{
                    name: 'realData',
                    data: that.detailData
                }]
            });
            this.chartConstruct = true;
        },

        requestRealData: function(series) {
            this.getOverviewData();
            this.getDetailData();
            this.waitForBuild(true, series);
        },

        updateLineChart: function() {
            var chart = $('#udataRealDataChart').highcharts(),
                series = chart.series[0];
            series.setData(this.detailData);
            // 启动定时器
            this.realTimer = setInterval(function() {
                this.requestRealData(series);
            }, 60000);
        },

        run: function() {
            var spm = common.getSPMId();
            if (spm == "608.1000566") {
                this.isJuhuasuan = true;
            }
            this.autoLogin();
        },

        stop: function() {
            this.dialogModule && this.dialogModule.hide();
            $(".udata-pageData-mask").hide();
            // 重置初始参数
            this.type = "pv";
            this.latests = [];
            this.isJuhuasuan = false;
            // 处理实时框
            this.loading && this.loading.show();
            this.container && this.container.hide();
            this.fail && this.fail.hide();
            // 处理计时器
            clearTimeout(waiter);
            waiter = null;
            clearInterval(this.realTimer);
            this.realTimer = null;
        }
    };
})(jQuery);