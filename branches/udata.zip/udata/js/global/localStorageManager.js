/**
 * 本地存储管理模块
 * @author : yu.yuy
 * @createTime : 2013-05-12
 */
 (function($){
 	$.namespace('UData.localStorageManager');
 	UData.localStorageManager = {
 		init : function(){
 			var that = this;
 			if(!that.getIsRunningStatus()){
 				that.changeIsRunningStatus(false);
 			}
 		},
 		get : function(k){
 			return window.localStorage.getItem(k);
 		},
 		set : function(k,v){
 			window.localStorage.setItem(k,v);
 		},
 		getIsRunningStatus : function(){
 			var that = this;
 			return that.get('UDataIsRunning')===true.toString();
 		},
 		changeIsRunningStatus : function(status){
 			var that = this;
 			that.set('UDataIsRunning',status);
 		}
 	};
 	UData.localStorageManager.init();
 })(jQuery);