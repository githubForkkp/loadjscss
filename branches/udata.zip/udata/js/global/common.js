/**
 * 公共逻辑模块
 * @author : yu.yuy
 * @createTime : 2013-05-30
 */
(function($){
 	$.namespace('UData.common');
 	var div,
        pageBody = $(document.body);

 	UData.common = {
 		init : function(){
            var that = this;
            // 确保在chrome.extension初始化后执行
            var timer = setTimeout(function() {
                if (chrome.extension) {
                    clearTimeout(timer);
                    timer = null;
                    that.startup(chrome.extension.getURL(""));
                } else {
                    timer = setTimeout(arguments.callee, 50);
                }
            }, 50);
 		},
 		getMetaSPMData : function(key){
 			var metas = $('meta'),
 			meta,
 			metaName,
 			originSpmId,
 			a,
 			tmp,
 			isWangPu,
 			spmAB = '';
 			if(metas){
 				for (var i = metas.length - 1; i >= 0; i--) {
 					meta = metas.eq(i);
 					metaName = meta.attr('name');
 					if(metaName == key){
 						originSpmId = meta.attr('content');
 						if(originSpmId.indexOf(':')>=0){
 							a = originSpmId.split(':');
 							originSpmId = a[1];
 						}
 						isWangPu = (originSpmId.indexOf('110') == 0);
 						spmAB = isWangPu?'':originSpmId;
 						break;
 					}
 				};
 			}
 			return spmAB;
 		},
 		getSPMIdFromWuHeng: function(spm_a, spm_b) {
 			var spm_ab = '';
 			// 如果页面上存在 _SPM_a、_SPM_b，表示页面上有无痕埋点
			spm_a = spm_a.replace(/^{(\w+)}$/g, "$1");
			spm_b = spm_b.replace(/^{(\w+)}$/g, "$1");
			spm_ab = spm_a + "." + spm_b;
			return spm_ab;
 		},
 		getSPMId : function(){
 			var that = this,
 			spmAB = '',
 			a;
 			if (that.spma && that.spmb) {
 				return that.getSPMIdFromWuHeng(that.spma, that.spmb);
 			}
 			spmAB = that.getMetaSPMData('data-spm') || that.getMetaSPMData('spm-id');
 			if (!spmAB) {
 				return spmAB;
 			}
 			/**
			 * 从 body 标签中获取第二位
			 * 形如：<body data-spm="1000484">...</body>
			 */
			var body = document.getElementsByTagName("body");
			var spmB;
			a = spmAB.split(".");
			body = body && body.length ? body[0] : null;
			if (body) {
				spmB = $(body).attr('data-spm');
				if (spmB) {
					// body 标签中存在 spm 第二位
					spmAB = a[0] + "." + spmB;
				}
			}
			return spmAB;
 		},
 		manageNextDay: function(nextDayBtn, date, maxDate){
			var dateTimes = +new Date(date),
			maxDateTimes = +new Date(maxDate);
			nextDayBtn[(dateTimes >= maxDateTimes)?'addClass':'removeClass']('udata-day-btn-disabled');
		},
		getLocalFile: function(path, dict) {
			var content, key, reg, root;
			if (dict == null) {
				dict = {};
			}
			root = chrome.extension.getURL("");
			content = "";
			$.ajax({
				url: root + path,
				cache: false,
				async: false,
				success: function(r) {
					return content = r.replace(/#\{root\}/g, root);
				}
			});
			dict["root"] = root;
			dict["_rnd_"] = Math.random();
			for (key in dict) {
				if (dict.hasOwnProperty(key)) {
					reg = new RegExp("#\{" + key + "\}", "g");
					content = content.replace(reg, dict[key]);
				}
			}
			return content;
		},
		getLocalHtml: function(path, dict) {
			var html;
			if (dict == null) {
				dict = {};
			}
			dict["charset"] = document.charset;
			html = cf.getLocalFile(path, dict);
			html = html.replace(/#\{charset\}/g, document.charset).replace(/\.(css|js)"/ig, ".$1?r=" + Math.random() + "\"");
			return html;
		},
		getAppIdInPage: function() {
			var html, m;
			html = $("html").html();
			m = html.match(/<script>[\s\S]*?window\.g_config\s*=\s*\{[\s\S]*?appId\s*?:\s*?(\w+?)/);
			if (m) {
				return m[1];
			} else {
				return "";
			}
		},
        buildLoading : function(){
            var that = this;
            that.loadingBox = $('<div class="udata-spm-position-loading"></div>');
            that.loadingBox.appendTo(pageBody);
        },
        setFakeDay: function(date) {
            $(".udata-date-overlay").text(date.split("-")[2]);
        },
        numFormat: function(num) {
            var arr_n = num.toString().split("."),
                n = arr_n[0],
                number = Number(n).toString(),
                length = number.length,
                numArr = number.split(""),
                ret;
            if (length >= 7) {
                numArr.splice(length-3, 0, ",");
                numArr.splice(length-6, 0, ",");
            } else if (length >= 4) {
                numArr.splice(length-3, 0, ",");
            }
            ret = numArr.join("");
            if (arr_n.length != 1 && arr_n[1] != 0) {
                ret += "."+arr_n[1];
            }
            return ret;
        },
        getDate: function(curDate, interDay) {
            var interDay = interDay ? +interDay : 0,
                d = curDate ? curDate : new Date(),
                timestamp = (+d) + interDay*24*60*60*1000,
                day = new Date(timestamp);

            var formattor = function(n) {
                var ret = n;
                if (n < 10) {
                    ret = "0" + n;
                }
                return ret;
            };

            return day.getFullYear() + "-" + formattor(day.getMonth()+1) + "-" + formattor(day.getDate());
        },
        hasReady: function() {
            return this.isReady;
        },
        getXwjId: function() {
            return this.xwj_id;
        },
        interceptor: function() {
            window.postMessage({
                src: "htmlData",
                spma: window._SPM_a,
                spmb: window._SPM_b,
                xwj_id: window._ap_xwj ? window._ap_xwj.getId ? window._ap_xwj.getId() : null : null
            }, "*");
        },
        startup: function() {
            var that = this;
            var script_string = "(" + that.interceptor.toString() + ")();";
            var script = document.createElement("script");
            script.innerHTML = script_string;
            document.getElementsByTagName("head")[0].appendChild(script);

            window.addEventListener("message", function(e) {
                if (e.data.src == "htmlData") {
                    that.spma = e.data.spma;
                    that.spmb = e.data.spmb;
                    that.xwj_id = e.data.xwj_id;
                    that.isReady = true;
                }
            });
        },
        url2obj: function(url) {
            if (url[0] == "?") {
                url = url.substring(1);
            }
            var paramArr = url.split("&"), ret = {};
            for(var i = 0; i < paramArr.length; i ++) {
                var keyValue = paramArr[i].split("=");
                ret[keyValue[0]] = unescape(keyValue[1]);
            }
            return ret;
        },
        simpleTpl: function(str, obj) {
            return str.replace(/{{(\w+)}}/g, function(s, key) {
                return obj[key];
            });
        }
 	};
 	UData.common.init();
 })(jQuery);
