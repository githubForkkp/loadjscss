/**
 * 后台逻辑模块，管理插件开关
 * @author : yu.yuy
 * @createTime : 2013-05-10
 */
 (function($){
 	$.namespace('UData.background');
 	var localStorageManager = UData.localStorageManager,
 	    isRunning,
        watching_tabs = {};
 	//menu = UData.menu;
 	UData.background = {
 		init : function(){
 			var that = this;
 			isRunning = localStorageManager.getIsRunningStatus();
 			that.setIcon(isRunning);
 			chrome.browserAction.onClicked.addListener(function(){
 				that.run();
 			});

            chrome.tabs.onUpdated.addListener(function(tab_id, change_info, tab) {
//      console.log([tab_id, tab.url]);
                var sendResponse;
                if (tab_id in watching_tabs) {
                    sendResponse = watching_tabs[tab_id];
                    sendResponse({
                        tab_url: tab.url
                    });
                    delete watching_tabs[tab_id];
                    chrome.tabs.remove(tab.id);
                }
            });
 			that.receiveMessage();
 		},
 		sendMessage : function(flag){
            var message;
            if (flag === "collapse") {
                message = flag;
            } else {
                message = flag?"uDataRun":"uDataClose";
            }
 			chrome.windows.getAll({populate: true}, function(windows) {
		    	var w,t;
		    	for (w=0; w<windows.length; w++) {
		    		for (t=0; t<windows[w].tabs.length; t++) {
		    			chrome.tabs.sendRequest(windows[w].tabs[t].id, message);
		    		}
		     	}
			});
 		},
 		receiveMessage : function(){
 			var that = this;
 			chrome.extension.onMessage.addListener(function(request, sender, sendResponse){
                if (request.type == "app_spmFind::open_tab") {
                    var tab_id;
                    var tab_url;
                    chrome.tabs.create(request.options, function (tab) {
                        tab_id = tab.id;
                        tab_url = tab.url;

                        watching_tabs[tab_id] = {
                            sendResponse: sendResponse,
                            data: request.data
                        };
                    });

                    return true;

                } else if (request.type == "app_spmFind::tab_opened") {
                    chrome.tabs.getSelected(null, function(tab) {
                        data = watching_tabs[tab.id];
                        if (!data) return;

                        sendResponse(data);
                    });

                    return true;
                } else if (request.type == "collapse") {
                    localStorageManager.set("udata-collapse", request.collapse);
                } else if (request.type == "app_spmMarkInvalidLinks::open_tab") {

                    var tab_id;
                    var tab_url;
                    chrome.tabs.create(request.options, function (tab) {
                        tab_id = tab.id;
                        tab_url = tab.url;
                        watching_tabs[tab_id] = sendResponse;
                    });

                    return true;
                }else {
                    if(request.closeUData === true){
                        that.setIcon(false);
                        localStorageManager.changeIsRunningStatus(false);
                        that.sendMessage(false);
                        isRunning = false;
                    } else{
                        var message;
                        if ((message = localStorageManager.get("udata-collapse")) && (message === "collapse")) {
                            // do nothing
                        } else {
                            message = null;
                        }
                        sendResponse({'isRunning': isRunning, 'collapse': message});
                    }
                }
		    });
 		},
 		run : function(){
 			var that = this,
 			oldStatus = localStorageManager.getIsRunningStatus();
 			isRunning = !oldStatus;
 			that.setIcon(isRunning);
 			localStorageManager.changeIsRunningStatus(isRunning);
 			that.sendMessage(isRunning);
 		},
 		setIcon : function(isRunning){
 			var path = isRunning ? "/images/icons/icon.png":"/images/icons/icon_stop.png";
 			chrome.browserAction.setIcon({path:path});
 		}
 	};
 	UData.background.init();
 })(jQuery);