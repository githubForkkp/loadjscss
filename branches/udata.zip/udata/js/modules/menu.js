/**
 * 主菜单模块--第2版
 * @author : gonghao.gh
 * @createTime : 2013-08-08
 */
(function($) {
    $.namespace('UData.menu');
    var common = UData.common,
        pageBody = $(document.body);

    UData.menu = {

        init: function() {
            var that = this;
            that.pageBody = $(document.body);
            that.menuBar = null;
            that.calendar = null;
            that.previousDay = null;
            that.nextDay = null;
            that.currentFunction = null;
            chrome.extension.sendMessage({}, function(res){
                if (res.collapse) {
                    that.collapse = true;
                }
                if(res.isRunning){
                    that.run();
                }
            });
            chrome.extension.onRequest.addListener(function(request) {
                if (request === "uDataRun") {
                    console.info('uData开启');
                    that.run();
                }
                else if(request === "uDataClose") {
                    console.info('uData关闭');
                    that.close();
                }
            });
        },

        buildMenu: function() {
            var that = this,
                html = '';

            html += '<div id="udataMenu" class="udata-menu udata-collapsed">';
            html +=     '<header>';
            html +=         '<div class="udata-cap">';
            html +=             '<span class="udata-collapse-btn udata-active-btn"></span>';
            html +=             '<span class="udata-menu-close-btn udata-active-btn" data-udata-beacon="udata.3.1"></span>';
            html +=         '</div>';
            html +=         '<div class="udata-header">';
            html +=             '<div class="udata-logo">';
            html +=                 '<a href="javascript:void(0);" class="udata-a-wrapper"></a>';
            html +=             '</div>';
            html +=             '<h1 class="udata-menu-name">';
            html +=                 '<a href="javascript:void(0);" class="udata-a-wrapper">uData</a>';
            html +=             '</h1>';
            html +=         '</div>';
            html +=     '</header>';
            html +=     '<div class="udata-time-control">';
            html +=         '<span class="udata-previous-day-btn udata-active-btn" data-udata-beacon="udata.1.1"></span>';
            html +=         '<span class="udata-next-day-btn udata-active-btn" data-udata-beacon="udata.1.2"></span>';
            html +=         '<ins class="udata-date-overlay"></ins>';
            html +=         '<input class="udata-calendar" readonly="readonly" data-udata-beacon="udata.1.3"/>';
            html +=         '<i class="udata-calendar-mask"></i>';
            html +=     '</div>';
            html +=     '<div class="udata-page-click-module udata-menu-module">';
            html +=         '<h3 class="udata-menu-title">页面点击</h3>';
            html +=         '<span class="udata-page-click-more" data-function-name="pageData" data-udata-beacon="udata.2.7">详情></span>';
            html +=         '<dl class="udata-page-info">';
            html +=             '<dt>总PV:<span class="udata-small-font udata-total-pv"></span></dt>';
            html +=             '<dt>总UV:<span class="udata-small-font udata-total-uv"></span></dt>';
            html +=             '<dt>点PV:<span class="udata-small-font udata-click-pv"></span></dt>';
            html +=             '<dt>点UV:<span class="udata-small-font udata-click-uv"></span></dt>';
            html +=         '</dl>';
            html +=         '<div>';
            html +=             '<div class="udata-click-setting">';
            html +=                 '<h4 class="udata-setting-title"><span class="udata-short">点击</span>设置:</h4>';
            html +=             '</div>';
            html +=             '<dl class="udata-click-function udata-setting-column">';
            html +=                 '<dt data-function-name="spmPosition" data-function-param="pv" data-remain="true" data-udata-beacon="udata.2.1">PV</dt>';
            html +=                 '<dt data-function-name="spmPosition" data-function-param="uv" data-remain="true" data-udata-beacon="udata.2.2">UV</dt>';
            html +=                 '<dt data-function-name="spmModule" data-udata-beacon="udata.2.3">区块</dt>';
            html +=                 '<dt data-function-name="heatmap" data-udata-beacon="udata.2.8">热图</dt>';
            html +=             '</dl><dl class="udata-click-params udata-setting-column">';
            html +=                 '<dt>数值</dt>';
            html +=                 '<dt data-mode="rate">占比</dt>';
            /*
            html +=                 '<dt class="udata-real-data-btn" data-mode="real">实时</dt>';
            */
            html +=                 '<dt id="udata-click-slider" class="udata-click-slider"></dt>';
            html +=             '</dl>';
            html +=         '</div>';
            html +=     '</div>';
            html +=     '<div class="udata-other-function">';
            /*
            html +=         '<div class="udata-page-path-module udata-menu-module">';
            html +=             '<h3 class="udata-func-module udata-menu-title">路径分析</h3>';
            html +=         '</div>';
            */
            html +=         '<div class="udata-real-time-module udata-menu-module">';
            html +=             '<h3 class="udata-real-click udata-func-module udata-menu-title" data-function-name="realData" data-udata-beacon="udata.3.8">实时数据</h3>';
            html +=         '</div>';
            html +=         '<div class="udata-help-module udata-menu-module">';
            html +=             '<dl class="udata-help-list">';
            html +=                 '<dt class="udata-wangwang-help"><a target="_blank" href="http://www.taobao.com/webww/ww.php?ver=3&touid=%E5%BA%9E%E9%83%BD&siteid=cntaobao&status=2&charset=utf-8"><span class="udata-short">业务</span>反馈</a></dt>';
            html +=                 '<dt class="udata-video-help"><a target="_blank" href="http://shuju.taobao.ali.com/klc/baike/baikeInfo.htm?spm=0.0.0.0.oth9EP&id=366">帮助<span class="udata-short">中心</span></a></dt>';
            html +=             '</dl>';
            html +=         '</div>';
            html +=         '<div class="udata-tool-module udata-menu-module">';
            html +=             '<h3 class="udata-menu-title"><span class="udata-short">实用</span>工具<span class="udata-more-tools udata-active-btn udata-show-tool"></span></h3>';
            html +=             '<dl class="udata-tool-list">';

            html +=                 '<dt class="udata-valid-tool" data-function-name="spmChecker" data-udata-beacon="udata.3.3"><span class="udata-short">SPM有效</span>检测</dt>';
            
            html +=                 '<dt class="udata-wuhen-tool" data-function-name="goldLog" data-function-param="validate" data-udata-beacon="udata.3.7">无痕<span class="udata-short">打点</span></dt>';
            html +=                 '<dt class="udata-position-tool" data-function-name="spmFinder" data-udata-beacon="udata.3.4"><span class="udata-short">SPM页面</span>定位</dt>';
            html +=                 '<dt class="udata-fxing-tool"><a href="https://chrome.google.com/webstore/detail/%E9%A3%8E%E5%BD%A2/cndbjbpmfljdjpaklnjaokefakmiheii" target="_blank">风行<span class="udata-short">数据</span></a></dt>';
            html +=             '</dl>';
            html +=         '</div>';
            html +=     '</div>';
            html += '</div>';

            that.menuBar = $(html);
            if (that.collapse) {
                that.menuBar.removeClass("udata-collapsed").addClass("udata-collapse");
            }
            pageBody.append(that.menuBar);
            that.calendar = that.menuBar.find('.udata-calendar').first();
            that.previousDay = that.menuBar.find('.udata-previous-day-btn').first();
            that.nextDay = that.menuBar.find('.udata-next-day-btn').first();
            that.confirmStart();
        },

        buildSlider: function() {
            var that = this;
            this.slider = this.menuBar.find(".udata-click-slider");
            this.slider.slider({
                orientation: "vertical",
                min: 1,
                max: 8,
                value: 8,
                slide: function(event, slider) {
                    that.showLevel(slider.value);
                }
            });
        },

        // 根据不同的level显示label
        showLevel: function(level) {
            var lastLevel = this.level ? this.level : 8,
                lastLevelClass = "udata-label-below-"+lastLevel,
                levelClass = "udata-label-below-"+level;

            this.level = level;
            pageBody.removeClass(lastLevelClass).addClass(levelClass);
        },

        addEvents: function() {
            var that = this,
                clazz = ["udata-menu udata-collapse", "udata-menu udata-collapsed"],
                index = 0;

            // 页面点击下功能
            that.menuBar.on('click', '.udata-click-function dt, .udata-tool-list dt, .udata-real-click', function() {
                var el = $(this),
                    func_name = el.data("function-name"),
                    func_param = el.data("function-param"),
                    func_remain = el.data("remain"),
                    func = UData.apps[func_name],
                    isReal = false;

                if (!func || el.hasClass("udata-func-disabled")) {
                    return;
                }

                // toggle
                if (el.hasClass("udata-current-sel")) {
                    var remain = el.data("remain");
                    that.currentFunctionEl.closest(".udata-menu-module").removeClass("udata-current-module");
                    that.currentFunctionEl.removeClass('udata-current-sel');
                    that.currentFunction.stop(remain);
                    that.currentFunction = null;
                    that.currentFunctionEl = null;
                    return;
                }

                if (func_param) {
                    isReal = $(".udata-real-data-btn").hasClass("udata-current-sel");
                    $(".udata-click-params").removeClass("udata-params-hide").addClass("udata-params-show");
                } else {
                    UData.apps.spmPosition.realDataShutdown();
                    $(".udata-click-params").removeClass("udata-params-show").addClass("udata-params-hide");
                }

                // 停止目前运行的功能
                if (that.currentFunctionEl) {
                    var remain = el.data("remain");
                    that.currentFunctionEl.closest(".udata-menu-module").removeClass("udata-current-module");
                    that.currentFunctionEl.removeClass('udata-current-sel');
                    that.currentFunction.stop(remain);
                    that.currentFunction = null;
                }
                el.addClass('udata-current-sel');
                el.closest(".udata-menu-module").addClass("udata-current-module");
                that.currentFunctionEl = el;
                that.currentFunction = func;
                func.run(that.calendar, that.nextDay, func_param, func_remain, isReal);
            });

            that.menuBar.on('click', '.udata-click-params > dt:not(#udata-click-slider)', function(e) {
                var el = $(this),
                    mode = el.data("mode");
                if (el.hasClass("udata-current-sel")) {
                    return;
                }

                $(".udata-current-sel", $(".udata-click-params")).removeClass("udata-current-sel");
                el.addClass('udata-current-sel');
                if (mode == "real") {
                    UData.apps.spmPosition.realDataStartup();
                } else if (mode == "rate") {
                    UData.apps.spmPosition.realDataShutdown();
                    pageBody.addClass("udata-spm-rate-mode");
                } else {
                    UData.apps.spmPosition.realDataShutdown();
                    pageBody.removeClass("udata-spm-rate-mode");
                }
            });

            that.menuBar.on('click', '.udata-page-click-more', function() {
                var el = $(this),
                    func_name = el.data("function-name"),
                    func = UData.apps[func_name];

                if (el.hasClass("udata-current-sel")) {
                    that.currentFunctionEl.removeClass('udata-current-sel');
                    that.currentFunction.stop();
                    that.currentFunction = null;
                    that.currentFunctionEl = null;
                    return;
                }

                if (that.currentFunctionEl) {
                    that.currentFunctionEl.removeClass('udata-current-sel');
                    that.currentFunction.stop();
                    that.currentFunction = null;
                }
                el.addClass('udata-current-sel');
                that.currentFunctionEl = el;
                that.currentFunction = func;
                func.run(that.calendar, that.nextDay);
            });

            that.menuBar.on('click', '.udata-collapse-btn', function() {
                that.menuBar.attr("class", clazz[index]);
                that.messageToCollapse(index);
                index = (index+1)%2;
            });

            that.menuBar.on('click', '.udata-previous-day-btn', function(e) {
                e.preventDefault();

                var el = $(this);
                if (el.hasClass("udata-day-btn-disabled")) {
                    return;
                }
                if (that.currentFunction && $.isFunction(that.currentFunction.gotoPreviousDay)) {
                    that.currentFunction.gotoPreviousDay(el);
                }
            });

            that.menuBar.on('click', '.udata-next-day-btn', function(e){
                e.preventDefault();

                var el = $(this);
                if (el.hasClass('udata-day-btn-disabled')) {
                    return;
                }
                if (that.currentFunction && $.isFunction(that.currentFunction.gotoNextDay)) {
                    that.currentFunction.gotoNextDay(el);
                }
            });

            that.menuBar.on('click', '.udata-show-tool', function() {
                var el = $(this),
                    toollist = $(".udata-tool-list");
                if (el.hasClass("udata-hide-tools")) {
                    toollist.slideUp();
                    el.removeClass("udata-hide-tools").addClass("udata-more-tools");
                } else if (el.hasClass("udata-more-tools")) {
                    toollist.slideDown();
                    el.removeClass("udata-more-tools").addClass("udata-hide-tools");
                }
            });

            that.menuBar.on('click', '.udata-menu-close-btn', function(e){
                e.preventDefault();
                that.close();
                that.messageToClose();
            });

            $(".udata-calendar-mask").on('mousedown', function() {
                return false;
            });
        },

        showPageData: function(date) {
            var that = this,
                url = 'http://shuju.taobao.ali.com/rms/pub/spmPageDateData.htm',
                spmId = common.getSPMId(),
                yesterday = common.getDate(-1),
                date = date || yesterday;

            $.get(url, {spmId: spmId, date: date, _: +new Date()}, function(res) {
                if (res.success) {
                    if (date != res.date) {
                        that.calendar.datepicker("setDate", res.date);
                        common.setFakeDay(res.date);
                    }
                    $(".udata-total-pv").text(common.numFormat(res.data.pv));
                    $(".udata-total-uv").text(common.numFormat(res.data.uv));
                    $(".udata-click-pv").text(common.numFormat(res.data.clickPv));
                    $(".udata-click-uv").text(common.numFormat(res.data.clickUv));
                } else {
                    if(o.message === '没有获取到对应数据'){
                        // do nothing
                    } else {
                        alert(o.message);
                    }
                }
            }, "json");
        },

        /*
        addSpmPageInfoUrl: function() {
            var that = this,
                url = 'http://shuju.taobao.ali.com/rms/resourceDetail/detail.htm?spm=a1z1j.2312617.0.22.hsOWz2&showType=2',
                spmPageId = common.getSPMId().split('.');
            console.info(spmPageId);
            console.info(spmPageId.length);
            if(spmPageId.length === 2){
                url += '&spma='+spmPageId[0]+'&spmb='+spmPageId[1];
            }
            console.info(url);
            $(".udata-spm-info").attr('href', url);
        }, */

        clearEvents: function() {
            this.menuBar.undelegate();
        },

        close: function() {
            var that = this;
            if(that.currentFunction){
                that.currentFunction.stop();
            }
            if(that.menuBar){
                that.menuBar.remove();
                that.menuBar = null;
            }
        },

        messageToCollapse: function(index) {
            var message = index == 0 ? "collapse" : "collapsed";
            chrome.extension.sendMessage({type: "collapse", collapse: message}, function(res){
                console.info('uData collapse');
            });
        },

        messageToClose: function() {
            chrome.extension.sendMessage({closeUData:true}, function(res){
                console.info('uData close');
            });
        },

        confirmStart: function() {
            var that = this;
            that.timer = setTimeout(function() {
                if (common.hasReady()) {
                    clearTimeout(that.timer);
                    that.timer = null;
                    // 默认打开第一个功能项
                    that.menuBar.find('.udata-click-function dt').eq(0).click();
                    // 默认选择“数值”项
                    that.menuBar.find('.udata-click-params dt').eq(0).addClass("udata-current-sel");
                } else {
                    that.timer = setTimeout(that.confirmStart, 200);
                }
            }, 200);
        },

        isRealDataPage: function() {
            var spm = common.getSPMId();
            if (spm != "608.1000566") {
                $(".udata-real-time-module > .udata-func-module").addClass("udata-func-disabled");
            } else {
                $(".udata-real-time-module > .udata-func-module").removeClass("udata-func-disabled");
            }
        },

        // 实时第二次及以上次关闭trigger的时候会触发两次，原因不明，暂时手动调用
        manualStop: function() {
            var that = this;
            that.currentFunctionEl.closest(".udata-menu-module").removeClass("udata-current-module");
            that.currentFunctionEl.removeClass('udata-current-sel');
            that.currentFunction.stop();
            that.currentFunction = null;
            that.currentFunctionEl = null;
            return;
        },

        run: function() {
            // 确认menu创建后调用点击
            this.buildMenu();
            this.buildSlider();
            this.addEvents();
            //this.addSpmPageInfoUrl();
            this.isRealDataPage();
        }
    };
    UData.menu.init();
})(jQuery);
