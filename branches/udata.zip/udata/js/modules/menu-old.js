/**
 * 主菜单模块
 * @author : yu.yuy
 * @createTime : 2013-05-09
 */
 (function($){
 	$.namespace('UData.menu');
 	var common = UData.common,
        gold = UData.apps.goldLog,
        self = this;
 	UData.menu = {
 		structure : [{
 			name : 'spmPosition',
 			nick : 'SPM位置',
 			beacon : 'udata.2.1',
 			subFunction : [{
 				name:'点击数',
 				func:'pv',
 				beacon : 'udata.2.1'
 			},{
 				name:'点击uv',
 				func:'uv',
 				beacon : 'udata.2.2'
 			}]}, //{
//            name:'goldLog',
//            nick:'黄金令箭',
//            beacon : 'udata.2.2',
//            subFunction : [{
//                name:'点击数',
//                func:'pv',
//                beacon : 'udata.2.1'
//            },{
//                name:'点击uv',
//                func:'uv',
//                beacon : 'udata.2.2'
//            },{
//                name:'检测',
//                func:'validate',
//                beacon : 'udata.2.2'
//            }]
    //   },{
 			// name : 'click',
 			// nick : '页面点击',
 			// beacon : 'udata.2.4'
 		//},
        {
            name : 'spmModule',
            nick : 'SPM模块',
            beacon : 'udata.2.3'
        },{
			name : 'commonData',
			nick : '公共数据',
			beacon : 'udata.3.5'
		}, {
            name : 'pageData',
            nick : '页面数据',
            beacon : 'udata.2.7'
         }],
 		init : function(){
 			var that = this;
 			that.pageBody = $(document.body);
 			that.menuBar = null;
 			that.calendar = null;
 			that.previousDay = null;
 			that.nextDay = null;
 			that.currentFunction = null;
 			chrome.extension.sendMessage({}, function(res){
      			if(res.isRunning){
      				that.run();
      			}
      		});
			chrome.extension.onRequest.addListener(function(request) {
			   if (request === "uDataRun") {
			      console.info('uData开启');
			      that.run();
			   }
			   else if(request === "uDataClose"){
					console.info('uData关闭');
					that.close();
			   }
			});
 		},
 		build : function(){
 			var that = this,
 			html = '<div id="udataMenu" class="udata-menu">';
 			html += '<header>';
 			html += '<h1 class="title"><a class="udata-logo" href="https://chrome.google.com/webstore/detail/udata/mmejbcacelkdcpaeccimglglbkeohlhe" title="uData">uData</a></h1>';
 			html += '<a title="关闭" href="#" class="udata-menu-close-btn" data-udata-beacon="udata.3.1"></a>';
 			html += '</header>';
 			html += '<div class="content">';
 			html += '<div class="time-control">';
 			html += '<div>';
 			html += '<a title="前一天" href="#" class="udata-previous-day-btn" data-udata-beacon="udata.1.1">前一天</a>';
 			html += '<a title="后一天" href="#" class="udata-next-day-btn" data-udata-beacon="udata.1.2">后一天</a>';
 			html += '</div>';
 			html += '<div>';
 			html += '<input placeholder="日期" readonly="readonly" class="udata-calendar" data-udata-beacon="udata.1.3"/>';
 			html += '</div>';
 			html += '</div>';
 			html += '<dl class="main-functions">';
 			html += that.buildMainFunctions();
 			html += '</dl>';
 			html += '<dl class="other-functions">';
 			html += '<dt>相关工具：</dt>';
 			html += '<dd>';
 			html += '<a id="spmPageInfo" target="_blank" href="#" title="SPM页面数据">SPM页面数据</a>';
            html += '<a id="udata-spmCheck" href="javascript:void(0);" data-udata-beacon="udata.3.3" title="黄金令箭检测">黄金令箭检测</a>';
 			//html += '<a data-function="" href="#" title="SPM资源定位">SPM资源定位</a>';
 			//html += '<a data-function="" href="#" title="公共数据">公共数据</a>';
 			html += '</dd>';
 			html += '<dt>常用链接：</dt>';
 			html += '<dd>';
 			html += '<a href="//shuju.taobao.ali.com/" title="淘数据">淘数据</a>';
 			html += '<a href="//analytics.corp.taobao.com/" title="页面显微镜">页面显微镜</a>';
 			html += '<a href="//goldminer.taobao.org/jobgroups/" title="黄金矿工">黄金矿工</a>';
 			html += '<a href="//hotspot.taobao.net:9999/" title="hotspot">hotspot</a>';
 			html += '</dd>';
 			html += '</dl>';
 			html += '</div>';
 			html += '<footer>';
 			html += '<div class="contact">';
 			html += '<a target="_blank" href="http://www.taobao.com/webww/ww.php?ver=3&touid=%E5%BA%9E%E9%83%BD&siteid=cntaobao&status=2&charset=utf-8"><img border="0" src="http://amos.alicdn.com/online.aw?v=2&uid=%E5%BA%9E%E9%83%BD&site=cntaobao&s=2&charset=utf-8" alt="问题反馈" />问题反馈</a>';
 			html += '</div>';
 			html += '</footer>';
 			html += '</div>';
 			that.menuBar = $(html);
 			that.pageBody.append(that.menuBar);
 			that.calendar = that.menuBar.find('.udata-calendar').first();
 			that.previousDay = that.menuBar.find('.udata-previous-day-btn').first();
 			that.nextDay = that.menuBar.find('.udata-next-day-btn').first();
 			that.spmPageInfo = that.menuBar.find('#spmPageInfo');
 			//添加哥伦布系统的spm页面信息链接
 			that.addSpmPageInfoUrl();
 		},
 		addEvents : function(){
 			var that = this;
 			that.menuBar.delegate('.main-functions dt','click',function(e){
 				var el = $(this),
 				content = el.next('dd');
 				func = eval(el.attr('data-function'));

                gold.clearCheck();
 				
 				if(that.currentFunctionEl){
 					that.currentFunctionEl.removeClass('udata-menu-current-function');
 					that.currentFunctionEl.next('dd').removeClass('udata-menu-unfold');
 					that.currentFunction.stop();
 					that.currentFunction = null;
 					if(that.currentFunctionEl[0] === el[0]){
 						that.currentFunctionEl = null;
	 					return;
	 				}
 				}
 				el.addClass('udata-menu-current-function');
 				that.currentFunctionEl = el;
 				that.currentFunction = func;
 				if(content.length){
 					content.addClass('udata-menu-unfold');
 					content.children().eq(0).click();
 				}
 				else{
 					func.run(that.calendar,that.nextDay);
 				}
 			});
 			that.menuBar.delegate('.main-functions dd>a','click',function(e){

 				e.preventDefault();
 				var el = $(this),
 				subFunction = el.attr('data-function');
 				if(that.currentSubFuncitonEl === el){
 					return;
 				}
 				if(that.currentSubFuncitonEl){
 					that.currentSubFuncitonEl.removeClass('current-sub-function');
 				}
 				el.addClass('current-sub-function');
 				that.currentSubFuncitonEl = el;
 				//run.call(that.currentFunction,that.calendar,subFunction);
 				that.currentFunction.run(that.calendar,that.nextDay,subFunction);
 			});
 			that.menuBar.delegate('.udata-previous-day-btn','click',function(e){
 				e.preventDefault();
 				var el = $(this),
 				currentDate,
 				yesterday;
 				if(el.attr('disabled')){
 					return;
 				}
 				if(that.currentFunction && $.isFunction(that.currentFunction.gotoPreviousDay)){
 					that.currentFunction.gotoPreviousDay(el);
 				}
 			});
 			that.menuBar.delegate('.udata-next-day-btn','click',function(e){
 				e.preventDefault();
 				var el = $(this),
 				tomorrow;
 				if(el.hasClass('udata-next-day-btn-disabled')){
 					return;
 				}
 				if(that.currentFunction && $.isFunction(that.currentFunction.gotoNextDay)){
 					that.currentFunction.gotoNextDay(el);
 				}
 			});
 			that.menuBar.delegate('.udata-menu-close-btn','click',function(e){
 				e.preventDefault();
 				that.close();
 				that.messageToClose();
 			});
 			that.menuBar.delegate('#spmPageInfo','click',function(e){
 				e.preventDefault();
 				var el = $(this),
 				url = el.attr('href'),
 				a,
 				currentDate = $.trim(that.calendar.val());
 				if(currentDate !== ''){
 					url += '&gmtDate='+currentDate;
 				}
 				window.open(url);
 			});
            that.menuBar.delegate('#udata-spmCheck', 'click', function() {
                $(".udata-menu-current-function").trigger("click");
                gold.run("validate");
            });
 		},
 		clearEvents : function(){
 			that.menuBar.undelegate();
 		},
 		buildMainFunctions : function(){
 			var that = this,
 			mainFunction,
 			subFunctionLength = 0,
 			subFunction,
 			subFunctionName,
 			subFunctionFunc,
 			html = '',
 			beacon;
 			for(var i=0,l=that.structure.length;i<l;i++){
 				mainFunction = that.structure[i];
 				html += '<dt data-function="UData.apps.'+mainFunction['name']+'" data-udata-beacon="'+mainFunction['beacon']+'">';
 				html += mainFunction['nick'];
 				html += '</dt>';
 				if(mainFunction.subFunction){
 					subFunctionLength = mainFunction.subFunction.length;
 					html += '<dd>';
 					for(var j=0;j<subFunctionLength;j++){
 						subFunction = mainFunction.subFunction[j];
 						subFunctionName = subFunction.name;
 						subFunctionFunc = subFunction.func;
 						beacon = subFunction.beacon;
 						html += '<a data-function="'+subFunctionFunc;
 						html += '" href="#" title="'+subFunctionName+'" data-udata-beacon="'+beacon+'">';
 						html += subFunctionName;
 						html += '</a>';
 					}
 					html += '</dd>';
 				}
 			}
 			return html;
 		},
 		addSpmPageInfoUrl : function(){
 			var that = this,
 			url = 'http://shuju.taobao.ali.com/rms/resourceDetail/detail.htm?spm=a1z1j.2312617.0.22.hsOWz2&showType=2',
 			spmPageId = common.getSPMId().split('.');
 			console.info(spmPageId);
 			console.info(spmPageId.length);
 			if(spmPageId.length === 2){
 				url += '&spma='+spmPageId[0]+'&spmb='+spmPageId[1];
 			}
 			console.info(url);
 			that.spmPageInfo.attr('href',url);
 		},
 		close : function(){
 			var that = this;
 			if(that.currentFunction){
 				that.currentFunction.stop();
 			}
 			if(that.menuBar){
 				that.menuBar.remove();
 				that.menuBar = null;
 			}
 		},
 		messageToClose : function(){
 			chrome.extension.sendMessage({closeUData:true}, function(res){
      			console.info('uData close');
      		});
 		},
 		run : function(){
 			var that = this;
 			that.build();
 			that.addEvents();
 			//默认打开第一个功能项
 			that.menuBar.find('dt').eq(0).click();
 		}
 	};
 	UData.menu.init();
 })(jQuery);
