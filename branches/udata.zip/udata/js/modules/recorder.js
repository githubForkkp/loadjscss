/**
 * 打点器
 * @author : yu.yuy
 * @createTime : 2013-6-3
 */
(function($){
	$.namespace('UData.recorder');
	var doc = $(document);
	UData.recorder = {
		baseUrl : '//log.mmstat.com/',
		createUrl : function(key){
			var that = this,
			now = +new Date();
			return that.baseUrl+key+'?t='+now;
		},
		send : function(key){
			var that = this,
			img = new Image(1,1);
            img.src = that.createUrl(key);
            img.onload = function(){
                this.onload = null;
            }
		},
		init : function(){
			var that = this;
			doc.delegate('[data-udata-beacon]','click',function(e){
				var el = $(this),
				key = el.attr('data-udata-beacon');
				that.send(key);
			});
		}
	};
	UData.recorder.init();
})(jQuery);